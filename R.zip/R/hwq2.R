data("cloud")
summary(b1 <- powerTransform(cbind(Rain, S, C, P) ~ 1, data=cloud))
summary(b1 <- powerTransform(cbind(Rain, S, C, P) ~ 1, data=cloud, subset=-2))
anova(p1 <- pod(m1,group=A))

m1<- lm(Rain^(1/3) ~ S + D + logb(C, 2) + I(P^(1/3)) ,data=cloud)
transformed <- yjPower(my.dependent.variable, lambda)
cloud$Rain <- cloud$Rain == "Rain^(1/3)"
library(ggplot2)

library(ggplot2)

ggplot(cloud, aes(x = A, y = Rain^(1/3))) + 
  geom_point() +
  stat_smooth(method = "lm", col = "red")

ggplotRegression(lm(Rain^(1/3) ~ S, data = iris))

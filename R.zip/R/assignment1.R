
rmarkdown::render("D:/R/assignment1.R", "pdf_document")

library(readxl)
data<-read_excel("C:/Users/glane/Downloads/project data.xlsx")
View(data)
library(tidyverse)
#Nopunishment
plot(data$Round_Nopunishment , data$Group3_No,type = "o" , ylab = "avg contribution" , col = "black" ,ylim = c(4, 60))
lines(data$Round_Nopunishment , data$Group4_No , type = "o", col = "red" )  
lines(data$Round_Nopunishment , data$Group5_No , type = "o", col = "blue" )
lines(data$Round_Nopunishment , data$Group28_No , type = "o", col = "green" )
lines(data$Round_Nopunishment , data$Group31_No , type = "o", col = "yellow" )
lines(data$Round_Nopunishment , data$Group34_No , type = "o", col = "violet" )
lines(data$Round_Nopunishment , data$Group35_No , type = "o", col = "pink" )
lines(data$Round_Nopunishment , data$Group45_No , type = "o", col = "brown" )
lines(data$Round_Nopunishment , data$Group52_No , type = "o", col = "gray" )
lines(data$Round_Nopunishment , data$Group54_No , type = "o", col = "purple" )
title("Average contribution to public goods game: without punishment")
legend("topright",lwd = 1, lty = 1, cex = 0.6,
       legend = c("Group3_No","Group4_No","Group5_No","Group28_No","Group31_No","Group34_No","Group35_No","Group45_No","Group52_No","Group54_No"),
       col = c("black", "red", "blue" ,"green" ,"yellow" ,"violet" ,"pink","brown", "gray" ,"purple")) 

#Punish
plot(data$Round_punishment , data$Group3_Punish,type = "o" , ylab = "avg contribution" , col = "black",ylim = c(4, 60))
lines(data$Round_punishment , data$Group4_Punish , type = "o", col = "red" )  
lines(data$Round_punishment , data$Group5_Punish , type = "o", col = "blue" )
lines(data$Round_punishment , data$Group28_Punish , type = "o", col = "green" )
lines(data$Round_punishment , data$Group31_Punish , type = "o", col = "yellow" )
lines(data$Round_punishment , data$Group34_Punish , type = "o", col = "violet" )
lines(data$Round_punishment , data$Group35_Punish , type = "o", col = "pink" )
lines(data$Round_punishment , data$Group45_Punish , type = "o", col = "brown" )
lines(data$Round_punishment , data$Group52_Punish , type = "o", col = "gray" )
lines(data$Round_punishment , data$Group54_Punish , type = "o", col = "purple" )
title("Average contribution to public goods game: with punishment")
legend("topright",lwd = 1, lty = 1, cex = 0.6,
      legend = c("Group3_Punish","Group4_Punish","Group5_Punish","Group28_Punish","Group31_Punish","Group34_Punish","Group35_Punish","Group45_Punish","Group52_Punish","Group54_Punish"),
      col = c("black", "red", "blue" ,"green" ,"yellow" ,"violet" ,"pink","brown", "gray" ,"purple"))          



#Nopunishment
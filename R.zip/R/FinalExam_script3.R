######## Instructions #########
### Please rename your r script to: "YourLastName_FinalExam_script.r"
### Please enter your name here ____________________


######################################################################       
# Category I [28 points total; 14 points each scenario]              #
#        Choose two (2) of the following to analyze                  #
######################################################################       


#####Scenario 1a -- see word doc for details
# Scenario 1a. – data = alcohol.txt
#   A researcher believes that, as a result of the pandemic, increased anxiety and 
#   depression coupled with decreased access to mental health resources may be resulting 
#   in increased alcohol consumption. In 2017, based on per capita consumption from 
#   alcoholic sales data, the population average number of drinks consumed was 13.6 drinks 
#   per week (adjusted for age 18 and older). This researcher randomly sampled people in 
#   2020 (mid pandemic) and asked how many drinks they had the previous week. Using the 
#   appropriate statistical analysis, test their research question and report and interpret 
#   the results.
alcohol<-read.delim("C:/Users/glane/Downloads/alcohol.txt",sep = ",")  #alcohol.txt 
View(alcohol)

#1. [4 points] Name statistical test: __correlation______

#2. [4 points] Perform the statistical test 
cor.test(alcohol$Age, alcohol$DrinksPerWeek)
cor.test(alcohol$Age, alcohol$Anxiety)

#3. [4 points] Report and interpret the results
#The rate of Age showed an insignificant, negative relationship with Drinks per week, r(48) = -0.25, t(48) = -1.78, p >0.001. 
#Age & Anxiety, insignificant, positive assocation,

#4. [2 points] Create a plot demonstrating your results
par(mfrow=c(1,2))
plot(alcohol$Age, alcohol$DrinksPerWeek, main="Age and \nDrinksPerWeek", xlab="Age", ylab="DrinksPerWeek")
plot(alcohol$Age, alcohol$Anxiety, main="Age and and \nAnxiety", xlab="Age", ylab="Anxiety")
par(mfrow=c(1,1))

#####Scenario 1b -- see word doc for details
# Scenario 1b. – data = dopamine.txt
#   Parkinson’s disease is characterized by a lack of dopamine caused by a loss of dopaminergic 
#   cells in the substantia nigra in the midbrain. A neuroscientist has been working on 
#   developing a new experimental drug that generates more dopaminergic cells in a rodent model. 
#   He injected half of the rodents with the experimental drug and half of the rodents with a 
#   saline injection. After several weeks, the dopaminergic cells in the rodents substantia nigra 
#   were counted. Using the appropriate statistical analysis, test whether the experimental drug 
#   was effective and report and interpret the results. 
dopamine<-read.delim("C:/Users/glane/Downloads/dopamine.txt",sep = ",")  #dopamine.txt 
View(dopamine)

#1. [4 points] Name statistical test: __paired samples t-test______

#2. [4 points] Perform the statistical test 
t.test(dopamine$DACellCount, dopamine$Rodent, paired = T)
mean(dopamine$DACellCount)
mean(dopamine$Rodent)
sd(dopamine$DACellCount)
sd(dopamine$Rodent)

(mean(dopamine$DACellCount) - mean(dopamine$Rodent))/(sd(dopamine$DACellCount - dopamine$Rodent))
#3. [4 points] Report and interpret the results
#Paired samples t-test to examine DACellCount on Rodent. 
#t(59) = 29.988, p < 0.001, The mean initial verbal score was 6106.8 and the mean verbal retake score was 30.5. 
#Posses highly significant positive relation
#4. [2 points] Create a plot demonstrating your results
avg <- c(mean(dopamine$DACellCount),
         mean(dopamine$Rodent))
barplot(avg, ylab="Mean DA cell count /nRodent", main="DACellCount")

plot(c(0:1), avg, type="o", axes=F, ylim=c(130,170))
axis(side=1, at=c(0,1), labels=c("1st", "2nd"))
axis(side=2, at=c(130,150,170), labels=c(130,150,170))

#####Scenario 1c -- see word doc for details
# Scenario 1c. – data = amygdala.txt
#   Emotional processing, particularly fearful emotion, has long been associated with activity in the 
#   amygdala in the brain. A researcher is interested in whether there is any relationship between 
#   consumption of media that elicits fear and the size of the amygdala. She collects anatomical MRI 
#   data from participants and measures the size of each person’s amygdala. She also asks each person 
#   to indicate how many hours per week on average they spend (1) watching fictional horror movies and 
#   (2) watching or reading the news. Using the appropriate statistical analysis, test whether amygdala 
#   size is associated with either of these two types of fearful media consumption. Report and interpret 
#   the results. 
amygdala<-read.delim("C:/Users/glane/Downloads/amygdala.txt",sep = ",")  #amygdala.txt 
View(amygdala)

#1. [4 points] Name statistical test: _____correlation__________________

#2. [4 points] Perform the statistical test 
cor.test(amygdala$AmygdalaSize, amygdala$ScaryMovieHours)
cor.test(amygdala$AmygdalaSize, amygdala$NewsHours)

#3. [4 points] Report and interpret the results
#The Amygdalasize has significant and positive effect with respect to SCarymovies
#t(43)=2.5728 , r(48) = 0.36 
#The Amygdalasize has insignificant and positive effect with respect to NewsHours
#t(43)=1.1522 , r(48) = 0.17

#4. [2 points] Create a plot demonstrating your results
par(mfrow=c(1,2))
plot(amygdala$AmygdalaSize, amygdala$ScaryMovieHours, main="Size and \nScaryMovieHours", xlab="Size", ylab="ScaryMovieHours")
plot(amygdala$AmygdalaSize, amygdala$NewsHours, main="AmygdalaSize and \nNewsHours", xlab="Size", ylab="NewsHours")
par(mfrow=c(1,1))

#####Scenario 1d -- see word doc for details
# Scenario 1d. – data = color_fmri.txt
#   We know that different features of visual stimuli, such as color and motion, are processed by different 
#   regions of visual cortex. A cognitive neuroscientist is interested in whether attention to these different 
#   features changes brain activity selectively within their associated regions. In an fMRI experiment, the 
#   researcher collects BOLD signal data (indirect measure of brain activity) from participants’ color 
#   processing region (V4) while they viewed moving, colored shapes. Each participant attended to the color of 
#   the shape on half of the trials and attended to the motion of the shape on the other half of the trials of 
#   the experiment. Using the appropriate statistical analysis, test their research question and report and 
#   interpret the results. 
color_fmri<-read.delim("C:/Users/glane/Downloads/color_fmri.txt",sep = ",")  #color_fmri.txt 
View(color_fmri)
#1. [4 points] Name statistical test: ______correlation_____________

#2. [4 points] Perform the statistical test 
cor.test(color_fmri$Participant, color_fmri$AttendMotion_SignalChange)
cor.test(color_fmri$Participant, color_fmri$AttendColor_SignalChange)
#3. [4 points] Report and interpret the results
#The Amygdalasize has insignificant and positive effect on motion
#t(22)=0.04379 , r(22) = 0.009 p>0.05
#The Amygdalasize has insignificant and negative effect on colour
#t(22)=-0.073753 , r(22) = -0.01 p>0.05

#4. [2 points] Create a plot demonstrating your results
par(mfrow=c(1,2))
plot(color_fmri$Participant, color_fmri$AttendMotion_SignalChange, main="Participant vs AttendMotion", xlab="Participant", ylab="AttendMotion")
plot(color_fmri$Participant, color_fmri$AttendColor_SignalChange, main="Participant vs AttendColor", xlab="Participant", ylab="AttendColor")
par(mfrow=c(1,1))

######################################################################       
# Category II [28 points total; 14 points each scenario]              #
#        Choose two (2) of the following to analyze                  #
######################################################################       
#####Scenario 2a -- see word doc for details
# Scenario 2a. – data = neurofeedback.txt
#   A researcher is interested in whether neurofeedback improves ADHD symptoms. Using EEG, one group of 
#   participants with ADHD received neurofeedback training once a week, while another group received neurofeedback 
#   training three times a week. A final group received sham neurofeedback training session (EEG is recorded but 
#   the feedback these participants receive isn’t based on their actual EEG data; “placebo” condition) once a week. 
#   After a month, the change in each participants ADHD symptoms were recorded (+ = increased symptoms; 
#   and - = decreased symptoms). If there is an effect at all, the scientists is interested in how all of the groups 
#   differed from one another (Tukey's HSD corrected). Using the appropriate statistical analysis, test the scientist’s 
#   research question and report and interpret the results. 
neurofeedback<-read.delim("C:/Users/glane/Downloads/neurofeedback.txt",sep = ",")  #neurofeedback.txt 
View(neurofeedback)
#1. [4 points] Name statistical test: ____one-way ANOVA test_____________

#2. [4 points] Perform the statistical test
# Compute the analysis of variance
res.aov <- aov(Participant ~ Group, data = neurofeedback)
# Summary of the analysis
summary(res.aov)

#3. [4 points] Report and interpret the results
#As the p-value is less than the significance level 0.05, we can conclude that there are significant differences between the groups highlighted with "*" in the model summary.

#4. [2 points] Create a plot demonstrating your results
par(mfrow=c(2,2))
plot(res.aov)



#####Scenario 2b -- see word doc for details
# Scenario 2b. – data = faces.txt
#   The N170 event-related potential (ERP) component is a negativity measured over occipital-temporal electrode sites using 
#   EEG elicited when participants perceive faces. A scientist is interested in whether this ERP component is sensitive to 
#   the emotional expression of faces during face perception. She collects EEG data from 27 participants during a face 
#   perception task. For 1/3 of the trials in the task, participants viewed faces with happy emotional expressions. For 
#   another 1/3 of the trials, participants viewed faces with angry emotional expressions. For the final 1/3 of trials, 
#   participants view images of scrambled faces (i.e., the control condition – all of the visual elements of a face were 
#   present, but scrambled such that a face could not be perceived). Amplitudes of the N170 are recorded for each trial type 
#   for each participant in the task. If there is an effect, the researcher is more specifically interested in 
#   (1) whether viewing any face compared to no face influences N170 amplitude, and (2) whether the type of emotional face 
#   (happy compared to angry) influences N170 amplitude. Using the appropriate statistical analysis, test the scientist’s 
#   research questions and report and interpret the results. 
faces.txt<-read.delim("C:/Users/glane/Downloads/faces.txt",sep = ",")  #faces.txt 
View(faces.txt)
#1. [4 points] Name statistical test: _____correlation________

#2. [4 points] Perform the statistical test 
cor.test(faces.txt$Participant, faces.txt$Scrambled_N170)
cor.test(faces.txt$Participant, faces.txt$Happy_N170)
cor.test(faces.txt$Participant, faces.txt$Angry_N170)

#3. [4 points] Report and interpret the results
#Scrambled faces are insignificant with negative correlation with participants
#t(25)= -0.91191 , p-value > 0.05 , r(25)= -0.1794218 
#Happy faces are insignificant with positive correlation with participants
#t(25)= 0.88517 , p-value > 0.05 ,r(25) = 0.1743226 
#Angry faces are insignificant with positive correlation with participants
#t(25)= 0.20812 , p-value > 0.05 ,r(25) = 0.04158705

#4. [2 points] Create a plot demonstrating your results
par(mfrow=c(1,3))
plot(faces.txt$Participant, faces.txt$Scrambled_N170, main="Participants vs scrambled", xlab="Participant", ylab="Scrambled")
plot(faces.txt$Participant, faces.txt$Happy_N170, main="Participants vs happy", xlab="Participant", ylab="happy")
plot(faces.txt$Participant, faces.txt$Angry_N170, main="Participants vs angry", xlab="Participant", ylab="angry")


#####Scenario 2c -- see word doc for details
# Scenario 2c. – data = Cognitive_covid.txt
#   Some patients who have recovered from COVID-19 have reported some lingering cognitive dysfunction (i.e., attention 
#   problems, memory problems, etc.). Some studies have also reported that the level of antibodies present after recovery 
#   are associated with severity of infection. A researcher is interested in whether the severity of COVID-19 infection, 
#   as measured by antibody level 6 months after infection (high number = more severe infection), can predict cognitive dysfunction, as measured by accuracy on 
#   a test measuring attention and memory function (higher score = better cognitive function). In other words, does the severity of COVID-19 infection explain a 
#   significant amount of variance in cognitive dysfunction scores? 
Cognitive_covid<-read.delim("C:/Users/glane/Downloads/Cognitive_covid.txt",sep = ",")  #Cognitive_covid.txt 
View(Cognitive_covid)
#1. [4 points] Name statistical test: _____linear regression__________

#2. [4 points] Perform the statistical test
model<-lm(Participant~CovidSeverity+CognitiveScore,data=Cognitive_covid)
summary(model)

#3. [4 points] Report and interpret the results
#Participant = -6.666165 + 14.410343(CovidSeverity) - 0.001505(CognitiveScore)

#4. [2 points] Create a plot demonstrating your results
par(mfrow=c(1,2))
plot(Cognitive_covid$Participant, Cognitive_covid$CovidSeverity, main="Participants vs CovidSeverity", xlab="Participant", ylab="CovidSeverity")
plot(Cognitive_covid$Participant, Cognitive_covid$CognitiveScore, main="Participants vs CognitiveScore", xlab="Participant", ylab="CognitiveScore")

######################################################################       
# Category III [14 points total]                                     #
#        Choose one (1) of the following to analyze                  #
######################################################################       
#####Scenario 3a -- see word doc for details
# Scenario 3a. – data = alcohol.txt
#   The same researcher from Scenario 1a is also interested in what factors collectively predict alcohol use. 
#   In addition to data on how many drinks participants consumed in the last week, the scientist also collected 
#   scores on measures of anxiety, depression, as well as the participant’s age. Specifically, he is interested 
#   (1) whether anxiety scores predict alcohol use, and (2) whether adding the factor of age to 
#   the model using anxiety improves the model (i.e., significantly increases the amount of 
#   variance explained in alcohol use). Using the appropriate statistical test, test whether (1) alcohol use is 
#   predicted by anxiety and depression scores (higher scores = more anxiety), and (2) whether adding a factor 
#   of age improves the model. Report and interpret the results. 
View(alcohol)
#1. [4 points] Name statistical test: ____linear regression_________

#2. [4 points] Perform the statistical test 
mod<-lm(Participant~DrinksPerWeek+Anxiety,data=alcohol)
summary(mod)

#adding age
mod1<-lm(Participant~DrinksPerWeek+Anxiety+Age,data=alcohol)
summary(mod1)

#3. [4 points] Report and interpret the results
#Participant = -7.58248 + 1.88(DrinksPerWeek)+0.061(Anxiety)
#Participant = -5.0 + 1.83(DrinksPerWeek)+0.067(Anxiety)-0.057(Age)
#Adding age has had any adverse effect since the model gives identical R squared values

#4. [2 points] Create a plot demonstrating your results
par(mfrow = c(2,2))
plot(mod)
plot(mod1)

#####Scenario 3b -- see word doc for details
# Scenario 3b. – data = TMS_depression.txt
#   Some studies have suggested that rTMS (repetitive TMS) applied to different regions of the brain can influence 
#   mood. A researcher is interested in whether this method may be helpful for depressed patients, and whether 
#   cognitive behavioral therapy could also enhance its effect. Depressed patients who were either already 
#   receiving cognitive behavioral therapy (CBT) or were not receiving any therapy were both split into two groups. 
#   Half of the patients in each therapy condition received rTMS to their dorsolateral prefrontal cortex, and 
#   half in each therapy condition received a sham condition of rTMS (i.e., TMS device was used but didn’t 
#   deliver any actual stimulation; a “placebo” condition). After a few weeks, depression scores were for all 
#   patients were measured (lower scores = fewer depression symptoms). Using the appropriate statistical analysis, 
#   test the scientist’s research question and report and interpret the results. If an interaction is present, 
#   simply describe what the interaction plot shows in your interpretation (i.e., you are not required to 
#   perform simple main effects analyses or follow-up post-hoc tests for this question). 
TMS_depression<-read.delim("C:/Users/glane/Downloads/TMS_depression.txt",sep = ",")  #Cognitive_covid.txt 
View(TMS_depression)
TMS_depression$Therapy<-factor(TMS_depression$Therapy, labels =c("No_Therapy", "CBT_Therapy"))
TMS_depression$rTMS <- factor(TMS_depression$rTMS , labels=c("Sham", "PrefrontalCortex"))
#1. [4 points] Name statistical test: ____factorial anova ________

#2. [4 points] Perform the statistical test 

model<-lm(Depression ~ rTMS+Participant+ rTMS*Therapy,data=TMS_depression)
summary(model)

#3. [4 points] Report and interpret the results
#Depression=65.94007-3.24906(rTMS1)+0.08051(Participant)-10.94343(Therapy1)-3.02344(rTMS1*Therapy)

#4. [2 points] Create a plot demonstrating your results
library(sjPlot)
plot(model)
plot_model(model,type = "pred", terms = c("rTMS", "Therapy"))


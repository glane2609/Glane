library(readxl)
data1<-read_xlsx("C:/Users/glane/Downloads/metad616_Assignment3_Problem1_Data.xlsx")

mean_r1 <- mean(data1$`Wait Time`)
sd_r1 <- sd(data1$`Wait Time`)
r1 <- rnorm(data1$`Wait Time` , mean_r1 , sd_r1)

z_norm1<-(r1-mean_r1)/sd_r1 ## standardized data
qqnorm(z_norm1) ## drawing the QQplot
abline(0,1)


#Inexperienced agents
mean_r2 <- mean(data1$`Inexperienced Agents`)
sd_r2 <- sd(data1$`Inexperienced Agents`)
r2 <- rnorm(data1$`Inexperienced Agents`,mean_r2,sd_r2)

z_norm2<-(r2-mean_r2)/sd_r2 ## standardized data
qqnorm(z_norm2) ## drawing the QQplot
abline(0,1)

ks.test(r1 ,r2 )
cor.test(r1 ,r2,method = "pearson")

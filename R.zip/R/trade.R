library(quantmod)
getSymbols("ITC.NS", src="yahoo" )

ITC.NS<-na.omit(ITC.NS)
str(SBIN.NS)


  SBIN.NS<-as_tibble(SBIN.NS, rownames = "DATE")
# str(ADANIGREEN.NS)
# library(lubridate)
SBIN.NS$DATE <- ymd(SBIN.NS$DATE)


library(xts)
library(data.table)
pb.date <- as.POSIXct(Sys.Date())
Sys.Date()
format(pb.date, tz="Asia/Kolkata",usetz=TRUE)

SBIN.NS <- as.xts(as.data.table(SBIN.NS))

library(TTR)
ema <-EMA(Cl(ADANIGREEN.NS))
View(ema)
# write.csv(sma,"sma.csv")
# tail(sma,n=45)
# 
# library(plotly)
 chartSeries(ITC.NS,
             subset='2020-01 09:15:00::2021-05 15:30:00',
             theme=chartTheme('white')
)
addEMA(n=50,on=1,col = "blue")
xts

chartSeries(ITC.NS,
            subset='2021-03-15 09:15:00::2021-05-25 15:30:00',
            theme=chartTheme('white')
)
# addEMA(n=50,on=1,col = "blue")
# addEMA(n=200,on=1,col = "red")
addSMA(n=9,on=1,col = "blue")
addSMA(n=21,on=1,col = "red")
addSMA(n=55,on=1,col = "black")

as.POSIXlt(DEN.NS)

library(tsfknn)
df <- data.frame(ds = index(SBIN.NS),
                 y = as.numeric(SBIN.NS[,'SBIN.NS.Close']))

predknn <- knn_forecasting(df$y,h=)
predknn$prediction
plot(predknn)

library(dplyr)
data<-read.csv("C:/Users/glane/Downloads/apartments.csv")
View(data)
library(caTools)
library(ggplot2)
#Problem2
#Question1
sample.split(data$twobed_rent,SplitRatio = 0.70)-> split_tag
subset(data, split_tag==T)->train
subset(data, split_tag==F)->test
nrow(train)
nrow(test)

lm(twobed_rent~twobed_sf+distance_from_tower+furnished+pool+laundry_in_unit+electricity+water,data=train)-> model1

predict(model1, newdata=test)-> predicted_values
head(predicted_values)

cbind(Actual=test$twobed_rent, Predicted=predicted_values)-> final_data
as.data.frame(final_data)->final_data
class(final_data)
head(final_data)


final_data$Actual - final_data$Predicted ->error
View(error)

#adding 0.1 to existing distance
data$distance_from_tower = 0.1 + data$distance_from_tower
data$distance_from_tower

#Building model
sample.split(data$twobed_rent,SplitRatio = 0.70)-> split_tag
subset(data, split_tag==T)->train1
subset(data, split_tag==F)->test1
nrow(train1)
nrow(test1)

lm(twobed_rent~twobed_sf+distance_from_tower+furnished+pool+laundry_in_unit+electricity+water,data=train1)-> model2

predict(model2, newdata=test1)-> predicted_values1
head(predicted_values1)

cbind(Actual1=test1$twobed_rent, Predicted1=predicted_values1)-> final_data1
as.data.frame(final_data1)->final_data1
class(final_data1)
head(final_data1)


final_data1$Actual1 - final_data1$Predicted1 ->error1
View(error1)

#Model for twobed_rent and Distance
sample.split(data$twobed_rent,SplitRatio = 0.70)-> split_tag
subset(data, split_tag==T)->train2
subset(data, split_tag==F)->test2
nrow(train2)
nrow(test2)
lm(twobed_rent~distance_from_tower, data= train2)-> model3
predict(model3, newdata=test2)-> predicted_values2
head(predicted_values2)

cbind(Actual2=test2$twobed_rent, Predicted2=predicted_values2)-> final_data2
as.data.frame(final_data2)->final_data2
class(final_data2)
head(final_data2)


final_data2$Actual2 - final_data2$Predicted2->error2
View(error2)

dropinprice = error1 - error
View(dropinprice)
#plot
ggplot(data=data,aes(x=twobed_rent,y=distance_from_tower))+geom_point()


#Question2
#additional 100 square feet
data$twobed_sf = 100 + data$twobed_sf
data$twobed_sf
sample.split(data$twobed_rent,SplitRatio = 0.70)-> split_tag
subset(data, split_tag==T)->train3
subset(data, split_tag==F)->test3
nrow(train3)
nrow(test3)

lm(twobed_rent~twobed_sf+distance_from_tower+furnished+pool+laundry_in_unit+electricity+water,data=train1)-> model4

predict(model4, newdata=test3)-> predicted_values3
head(predicted_values3)

cbind(Actual3=test3$twobed_rent, Predicted3=predicted_values1)-> final_data3
as.data.frame(final_data3)->final_data3
class(final_data3)
head(final_data3)


final_data3$Actual3 - final_data3$Predicted3 ->error3
View(error3)


#Model for Rent and square footage
sample.split(data$twobed_rent,SplitRatio = 0.70)-> split_tag
subset(data, split_tag==T)->train4
subset(data, split_tag==F)->test4
nrow(train4)
nrow(test4)
lm(twobed_rent~twobed_sf, data= train4)-> model5
predict(model5, newdata=test4)-> predicted_values4
head(predicted_values4)

cbind(Actual4=test4$twobed_rent, Predicted4=predicted_values4)-> final_data4
as.data.frame(final_data4)->final_data4
class(final_data4)
head(final_data4)

final_data4$Actual4 - final_data4$Predicted4 ->error4
View(error4)
#Plot
ggplot(data=data,aes(x=twobed_rent,y=twobed_sf))+geom_point()
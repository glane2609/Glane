library(dplyr)
data<-read.csv("C:/Users/glane/Downloads/load_summer.csv")
View(data)
library(caTools)
#Problem1
#Question1
sample.split(data$COAST,SplitRatio = 0.70)-> split_tag
subset(data, split_tag==T)->train
subset(data, split_tag==F)->test
nrow(train)
nrow(test)

lm(COAST~weekday,data=train)-> model1

predict(model1, newdata=test)-> predicted_values
head(predicted_values)

cbind(Actual=test$COAST, Predicted=predicted_values)-> final_data
as.data.frame(final_data)->final_data
class(final_data)
head(final_data)


final_data$Actual - final_data$Predicted ->error
View(error)

#Question2
sample.split(data$COAST,SplitRatio = 0.70)-> split_tag
subset(data, split_tag==T)->train1
subset(data, split_tag==F)->test1
nrow(train1)
nrow(test1)

lm(COAST~temp,data=train1)-> model2

predict(model2, newdata=test1)-> predicted_values1
head(predicted_values1)

cbind(Actual1=test$COAST, Predicted1=predicted_values1)-> final_data1
as.data.frame(final_data1)->final_data1
class(final_data1)
head(final_data1)


final_data1$Actual1 - final_data1$Predicted1 ->error1
View(error1)
library(ggplot2)
ggplot(data=data,aes(x=COAST,y=temp))+geom_point()+facet_grid(~weekday)

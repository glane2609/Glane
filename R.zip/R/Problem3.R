library(dplyr)
data<-read.csv("C:/Users/glane/Downloads/redline.csv")
View(data)
library(caTools)
library(ggplot2)
#Policies
sample.split(data$policies,SplitRatio = 0.70)-> split_tag
subset(data, split_tag==T)->train
subset(data, split_tag==F)->test
nrow(train)
nrow(test)

lm(policies~fire+age+income,data=train)-> model1

predict(model1, newdata=test)-> predicted_values
head(predicted_values)

cbind(Actual=test$policies, Predicted=predicted_values)-> final_data
as.data.frame(final_data)->final_data
class(final_data)
head(final_data)

final_data$Actual - final_data$Predicted ->error
View(error)

#Minority
sample.split(data$policies,SplitRatio = 0.70)-> split_tag
subset(data, split_tag==T)->train1
subset(data, split_tag==F)->test1
nrow(train1)
nrow(test1)

lm(minority~fire+age+income,data=train)-> model2

predict(model2, newdata=test)-> predicted_values1
head(predicted_values1)

cbind(Actual1=test$minority, Predicted1=predicted_values1)-> final_data1
as.data.frame(final_data1)->final_data1
class(final_data1)
head(final_data1)

final_data1$Actual1 - final_data1$Predicted1 ->error1
View(error1)

ggplot(data=data,aes(x=policies,y=minority,col=ZIP))+geom_point()+facet_grid(~ZIP)

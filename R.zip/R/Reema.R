Data1<- read.csv("C:/Users/glane/Downloads/NY.csv")
View(Data1)
Data2<- read.csv("C:/Users/glane/Downloads/TK.csv")
View(Data2)
data<- merge(Data1, Data2 , all = TRUE)
View(data)
 

library(dplyr)
#Selecting rows that contain numeric data
data<- select(data, id, host_id,latitude, longitude , price, minimum_nights , number_of_reviews,reviews_per_month,calculated_host_listings_count,availability_365)
#Removing missing values and NAs
data<- na.omit(data)
View(data)
pca_existing <- prcomp(data, scale. = TRUE)
plot(pca_existing)
scores_existing_df <- as.data.frame(pca_existing$x)
# Show first two PCs 
head(scores_existing_df[1:2])
#Now that we have them in a data frame, we can use them with plot.
plot(PC1~PC2, data=scores_existing_df, 
     main= "Neigbhourhood",
     cex = .1, lty = "solid")
text(PC1~PC2, data=scores_existing_df, 
     labels=rownames(data),
     cex=.8)

library(plotrix)

ramp <- colorRamp(c("yellow", "blue"))
colours_by_sum <- rgb( 
  ramp( as.vector(rescale(rowSums(data),c(0,1)))), 
  max = 255 )
plot(PC1~PC2, data=scores_existing_df, 
     main= "Neigbhourhood",
     cex = .1, lty = "solid", col=colours_by_sum)
text(PC1~PC2, data=scores_existing_df, 
     labels=rownames(data),
     cex=.8, col=colours_by_sum)



#Clustering
set.seed(1234)
existing_clustering <- kmeans(data, centers = 3)
existing_cluster_groups <- existing_clustering$cluster
plot(PC1~PC2, data=scores_existing_df, 
     main= "Neigbhourhood for 3",
     cex = .1, lty = "solid", col=existing_cluster_groups)
text(PC1~PC2, data=scores_existing_df, 
     labels=rownames(data),
     cex=.8, col=existing_cluster_groups)

set.seed(1234)
existing_clustering <- kmeans(data, centers = 4)
existing_cluster_groups <- existing_clustering$cluster
plot(PC1~PC2, data=scores_existing_df, 
     main= "Neigbhourhood for 4",
     cex = .1, lty = "solid", col=existing_cluster_groups)
text(PC1~PC2, data=scores_existing_df, 
     labels=rownames(data),
     cex=.8, col=existing_cluster_groups)

set.seed(1234)
existing_clustering <- kmeans(data, centers = 5)
existing_cluster_groups <- existing_clustering$cluster
plot(PC1~PC2, data=scores_existing_df, 
     main= "Neigbhourhood for 5",
     cex = .1, lty = "solid", col=existing_cluster_groups)
text(PC1~PC2, data=scores_existing_df, 
     labels=rownames(data),
     cex=.8, col=existing_cluster_groups)

set.seed(1234)
existing_clustering <- kmeans(data, centers = 6)
existing_cluster_groups <- existing_clustering$cluster
plot(PC1~PC2, data=scores_existing_df, 
     main= "Neigbhourhood for 6",
     cex = .1, lty = "solid", col=existing_cluster_groups)
text(PC1~PC2, data=scores_existing_df, 
     labels=rownames(data),
     cex=.8, col=existing_cluster_groups)

summary(pca_existing)

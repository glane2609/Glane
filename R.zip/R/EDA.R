options(scipen = 999)
data<- read.csv("C:/Users/glane/Downloads/Parkinson2.csv")
View(data)
library(ggplot2)
#Status vs Gender
ggplot(data = data,aes(x = Status, fill = Gender))+geom_histogram(bins = 50)

#Status vs Jitter
ggplot(data = data, aes(x=Status,y= Jitter_rel))+geom_point()
ggplot(data = data, aes(x=Status,y= Jitter_abs))+geom_point()
ggplot(data = data, aes(x=Status,y= Jitter_RAP))+geom_point()
ggplot(data = data, aes(x=Status,y= Jitter_PPQ))+geom_point()


#Status vs RPDE
ggplot(data = data, aes(x=Status,y= RPDE))+geom_point()

#Status vs DFA
ggplot(data = data, aes(x=Status,y= DFA))+geom_point()


#Clustering Q.2
library(cluster) 
library(dplyr)
library(factoextra)
data_new <- select(data,c("Jitter_rel" : "Delta12"))  #4-47 variables for clustering
View(data_new)

#Starting with centers = 3
k3 <- kmeans(data_new, centers = 3, nstart = 25)
k3

fviz_cluster(k3, data = data_new)


#Q.3
data_2 <- select(data,c("Status" : "Delta12"))

#Linear discriminant analysis - LDA
library(MASS)
library(caret)
training.samples <- data_2$Status %>%
  createDataPartition(p = 0.8, list = FALSE)
train.data <- data_2[training.samples, ]
test.data <- data_2[-training.samples, ]

# Estimate preprocessing parameters
preproc.param <- train.data %>% 
  preProcess(method = c("center", "scale"))
# Transform the data using the estimated parameters
train.transformed <- preproc.param %>% predict(train.data)
test.transformed <- preproc.param %>% predict(test.data)

model <- lda(Status~., data = train.transformed)
summary(model)
# Make predictions
predictions <- model %>% predict(test.transformed)
# Model accuracy
mean(predictions$class==test.transformed$Status)


#Question4
#RPDE
library(caTools)

sample.split(data_2$RPDE,SplitRatio = 0.65)-> split_tag
subset(data_2, split_tag==T)->train
subset(data_2, split_tag==F)->test

#RPDE
lm(RPDE~., data=train)-> model1
summary(model1)
predict(model1, newdata=test)->predicted_values
predicted_values

plot(model1)

#DFA
lm(DFA~., data=train)-> model2
summary(model2)
predict(model2, newdata=test)->predicted_values1
predicted_values1

plot(model2)


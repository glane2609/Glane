library(dplyr)
library(ggplot2)
library(statsr)
load("C:/Users/glane/Downloads/gss.Rdata")
View(gss)
class(gss)
str(gss)
#data for Race and nateduc
data <- filter(gss, year == 2012) %>%
  select(race,nateduc)
View(data)

#adding new factor level
data$nateduc <- factor(data$nateduc, levels=c(levels(data$nateduc), 0))

#convert to 0
data$nateduc[is.na(data$nateduc)]<-0
levels(data$nateduc)

# EDA
ggplot(data) + aes(x=race,fill=nateduc) + geom_bar(position = "fill") +
  labs(x="Race",y="Proportion",title="Race vs Education") +
  scale_fill_discrete(name="Opinion",labels=c("Too Little","About Right","Too Much","NA"))

ggplot(data) + aes(x=nateduc) + geom_bar() + ggtitle('Favourability to nateduc in Public Schools') + xlab('Types of favourability') + theme_bw()


#Inference
#Hypothesis
inference(x= race,y = nateduc, data = data, statistic = "proportion", type = "ht", null = 0 ,method = "theoretical",alternative="greater", success = "Oppose")

 

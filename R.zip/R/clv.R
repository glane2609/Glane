library(dplyr)
library(plyr)
data<- read.csv("C:/Users/glane/Downloads/marketing_data.csv")
#Convert date format into YYYY-MM-DD
data$Dt_Customer <- as.Date(as.character(data$Dt_Customer), format= "%m/%d/%y")


#Selectin only customer id , dt_customer(date) and income to find clv

data <- select(data,"�..ID","Dt_Customer","Income")
View(data)

# replace $ and comma with blank "" in the df$payment column.  and coerce that result to numeric
data$Income = as.numeric(gsub("[\\$,]","", data$Income))


getDataFrame <- function(df, startDate, endDate, tIDColName = "�..ID", tDateColName = "Dt_Customer", tAmountColName = "Income") {
  # sort data frame by date descendingly
  df <- df[order(df[ , tDateColName], decreasing = TRUE), ]
  
  # remove records outside date range [startDate, endDate]
  # == dplyr POTENTIALS ==
  df <- df[df[ , tDateColName] >= startDate, ]
  df <- df[df[ , tDateColName] <= endDate, ]
  
  # remove rows with duplicate Customer ID
  # == dplyr POTENTIALS ==
  newdf <- df[!duplicated(df[ , tIDColName]), ]
  
  # calc. the Recency [days] to the endDate; smaller the Recency == more recent
  # == dplyr POTENTIALS ==
  Recency <- as.numeric(difftime(endDate, newdf[ , tDateColName], units = "days"))
  # combine Days column to the newdf data frame
  newdf <- cbind(newdf, Recency)
  
  # sort data frame by ID to fit the return order of table() and tapply()
  newdf <- newdf[order(newdf[ , tDateColName]), ]
  
  # calc. the Frequency
  tmp <- as.data.frame(table(df[ , tIDColName]))
  Frequency <- tmp[ , 2]
  # combine Frequency to the newdf data frame
  newdf <- cbind(newdf, Frequency)
  
  # calc. the Monetary
  tmp <- as.data.frame(tapply(df[ , tAmountColName], df[ , tIDColName], sum))
  Monetary <- tmp[ , 1] / Frequency
  # combine Monetary to the newdf data frame
  newdf <- cbind(newdf, Monetary)
  
  return(newdf)
}	

#  set the "forecast" transaction time scope which are a bi-month purchasing cycle time
startDate_forecast <- as.Date("1/03/14","%m/%d/%y")
endDate_forecast <- as.Date("4/30/14","%m/%d/%y")

startDate_history <- as.Date("7/30/12", "%m/%d/%y")
 
endDate__history <- as.Date("6/29/14", "%m/%d/%y")

#get the rolled up R,F,M data frames
history <- getDataFrame(data,startDate_history,endDate__history)
forecast <- getDataFrame(data,startDate_forcast,endDate_forcast)

#Removing NAs
history<- na.omit(history)
forecast <- na.omit(forecast)

# set the purchasing cycle time as 60 days, and discrete the Recency 
history$Recency<- history$Recency %/% 60 


#discrete the Monetary by $100 interval
breaks<-seq(0,max(history$Monetary)+9,by=100)
history$Monetary<-as.numeric(cut(history$Monetary,breaks,labels=FALSE))


#add a Buy/No Buy column to the RFM data frame
Buy<-rep(0,nrow(history))
history<-cbind(history,Buy)


# find out the those who repurchased in the forcast period 1/03/14 - 4/30/14
history[history$�..ID %in% forecast$�..ID, ]$Buy<-1
train<-history
head(train)
View(train)


# get "Buy" percentages based on the variable Recency

getPercentages <- function(df,colNames){
  
  Var<-c(colNames,"Buy")
  
  df<-df[,names(df) %in% Var,drop=F]
  
  
  a <- ddply(df,Var,summarize,Number=length(Buy))
  b <- ddply(a,
             .(),
             .fun=function(x){
               transform(x, Percentage=with(x,round(ave(Number,a[,names(a) %in% Var,drop=F],FUN=sum)/ave(Number,a[,names(a) %in% colNames,drop=F],FUN=sum),2)))
             })
  
  b<-b[b$Buy==1,-1]
  
  return(b)
  
}

colNames<-c("Recency")
p<-getPercentages(train,colNames)


# get the Buy ~ Recency model
r.glm=glm(Percentage~Recency,family=quasibinomial(link='logit'),data=p)
p_r<-p


# get "Buy" percentages based on the variable Frequency
colNames<-c("Frequency")
p<-getPercentages(train,colNames)

# get the Buy ~ Frequency model
f.glm=glm(Percentage~Frequency,family=quasibinomial(link='logit'),data=p)
p_f<-p


# get "Buy" percentages based on the variable Monetary
colNames<-c("Monetary")
p<-getPercentages(train,colNames)


# get the Buy ~ Monetary model
m.glm=glm(Percentage~Monetary,family=quasibinomial(link='logit'),data=p)
p_m<-p

p_m <- na.omit(p_m)
View(p_m)
#plot and draw fit curves of Percentage ~ r,f,m


plot(p_r$Recency,p_r$Percentage*100,xlab="Recency",ylab="Probablity of Purchasing(%)")
lines(lowess(p_r$Recency,p_r$Percentage*100),col="blue",lty=2)

plot(p_f$Frequency,p_f$Percentage*100,xlab="Frequency",ylab="Probablity of Purchasing(%)")
lines(lowess(p_f$Frequency,p_f$Percentage*100),col="blue",lty=2)

plot(p_m$Monetary,p_m$Percentage*100,xlab="Monetary",ylab="Probablity of Purchasing(%)")
lines(lowess(p_m$Monetary,p_m$Percentage*100),col="blue",lty=2)


model<-glm(Buy~Recency+Frequency,family=quasibinomial(link='logit'),data=train)
summary(model)

pred_01<-predict(model,data.frame(Recency=c(0),Frequency=c(1)),type='response')


## caculating the CLV for a customer with R=0,F=1,average profit=1000,discount rate=0.05 for 3 periods
getCLV <- function(r, f, rev, cost, n, periods, dr, pModel) {
  df <- data.frame(period = c(0), r = c(r), f = c(f), n = c(n), value = c(0))
  
  for (i in 1:periods) {
    backstep <- df[df$period == i-1, ]
    nrow <- nrow(backstep)
    
    for (j in 1:nrow) {
      r <- backstep[j, ]$r
      f <- backstep[j, ]$f
      n <- backstep[j, ]$n
      p <- predict(pModel, data.frame(Recency = r, Frequency = f), type = "response")[1]
      buyers <- n * p
      
      # Predict odds of a "Buy" for this period
      df <- rbind( df, c(i, 0, f+1, buyers, buyers*(rev-cost) / (1+dr)^i ))
      
      # Predict odds of a "No-Buy" for this period
      df <- rbind( df, c(i, r+1, f, n-buyers, (n-buyers)*(0-cost) / (1+dr)^i ))
    }
  }
  
  return(sum(df$value))
}

v<-getCLV(0,1,1000,0,1,3,0.05,model)
v


library(ggplot2)
library(haven)
library(AER)
library(stargazer)
library(dplyr)
library(MASS)
library(tidyverse)
library(car)



data<-read_dta("C:/Users/glane/Downloads/birthweight_smoking.dta")
View(data)
resids_1 <- lm(birthweight~smoker+unmarried+nprevist,data=data)$residuals
View(resids_1)
resids_2 <- lm(drinks~smoker+unmarried+nprevist,data=data)$residuals
View(resids_2)
resids<- data.frame(resids_1,resids_2)
#FWL theorem summary
summary(lm(resids_1~resids_2,resids))

reg<- lm(birthweight~drinks+smoker+unmarried+nprevist,data=data)
#Full model summary
summary(reg)

stargazer(reg,type ="text",title="Regression Result")



#Dummy Variables, Interaction Terms 

data("CollegeDistance") 
View(CollegeDistance)
CollegeDistance$hispanic <- ifelse(CollegeDistance$ethnicity == "hispanic" , 1,0)
CollegeDistance$hispanic

CollegeDistance$afam <- ifelse(CollegeDistance$ethnicity == "afam" , 1,0)
CollegeDistance$afam

CollegeDistance$male <- ifelse(CollegeDistance$gender == "male", 1,0)
CollegeDistance$male

reg1<-lm(education~score+afam+hispanic+male+distance,data=CollegeDistance)
summary(reg1)

stargazer(reg1,type ="text",title="Regression Result")

#Correlation
CollegeDistance$corr<-cor(CollegeDistance$male , CollegeDistance$score)
CollegeDistance$corr

View(CollegeDistance)

NewReg<-lm(education~score+afam+hispanic+male+distance+corr,data=CollegeDistance)
summary(NewReg)

stargazer(NewReg,type ="text",title="Regression Result")

#Joint Hypothesis Testing and R2 
data("MASchools") 
library(dplyr)

MASchools_subset<- select(MASchools,expreg,stratio,income,score8,english)
MASchools_subset <- na.omit(MASchools_subset)

reg2<-lm(score8~expreg+stratio+income+english,data=MASchools_subset)
summary(reg2)

predicting_score <- predict(reg2, newdata = MASchools_subset)

residuals(reg2)
sse <- sum((fitted(reg2) - mean(MASchools_subset$score8))^2)
ssr<- sum((fitted(reg2) - MASchools_subset$score8)^2)
sst <- sse + ssr
Rsq<- 1 - (ssr/sst)
Rsq

linearHypothesis(reg2, c("stratio=0", "income=0"))

#The entry value is the overall  F-statistics and it equals the result of linearHypothesis().  
#F -test rejects the null hypothesis that the model has no power in explaining test scores. It is important to know that the  
#F-statistic reported by summary is not robust to heteroskedasticity

#Question 4: Probit, Logit, Linear Probability Model 
data("Boston") 
View(Boston) 

median(Boston$crim)
Boston$HighCrime <- ifelse(Boston$crim > median(Boston$crim), 1, 0)
Boston$HighCrime 

#Probit
reg3<-glm(HighCrime~indus+dis+tax+ptratio,data=Boston, family=binomial(link = "probit"))
summary(reg3)

HighCrime<-predict(reg3,newdata = data.frame(indus = 10, dis = 4,tax = 330, ptratio = 18,type = "response"))
HighCrime

stargazer(reg3,type ="text",title="Regression Result")

#Logit regression
reg4<-glm(HighCrime~indus+dis+tax+ptratio,data=Boston, family=binomial(link = "logit"))
summary(reg4)

HighCrime<-predict(reg4,newdata = data.frame("indus" = 10, "dis" = 4,"tax" = 330, "ptratio" = 18,type = "response"))
HighCrime

stargazer(reg4,type ="text",title="Regression Result")
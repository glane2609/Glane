load("C:/Users/glane/Downloads/bes15.Rda")
View(bes)
bes<- na.omit(bes)

library(lme4)
library(caTools)

sample.split(bes$eurefdoOver,SplitRatio = 0.65)-> split_tag
subset(bes, split_tag==T)->train
subset(bes, split_tag==F)->test

glmer(eurefdoOver~gender+lowed+highed+c_Con17_s+c_leaveHanretty_s+c_whitebritish_s+c_deprived_s+(1|ageGroup), data=train, family = "binomial")-> mod_log1
summary(mod_log1)

test<- filter(test,eurefdoOver==1)
predict(mod_log1,newdata=test,type="response")->result_log1
head(result_log1)
range(result_log1)
table(test$eurefdoOver, result_log1>0.4)

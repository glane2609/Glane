install.packages("BiocManager")
BiocManager::install("GEOquery")
install.packages("survminer")
library(GEOquery)
library(survminer)
gse <- getGEO('GSE7390')[[1]]
View(pData(gse))

write.csv(pData(gse),"gse.csv")

library(dplyr)
s_data <- pData(gse) %>% 
  dplyr::select(geo_accession, characteristics_ch1,contains('tissue'))

library(janitor)
s_data <- clean_names(s_data)

library(survival)
library(survminer)

fit <- survfit(Surv(characteristics_ch1) ~ tissue_ch1, data = s_data)
ggsurvplot(fit, data = s_data,pval = TRUE)
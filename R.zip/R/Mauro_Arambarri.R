#docker run -d -p 4445:4444 selenium/standalone-chrome ------> run it in terminal after starting docker application
#docker ps  -----> to check if it has started


remDr <- RSelenium::remoteDriver(remoteServerAddr = "localhost",port = 4445L,browserName = "chrome")
remDr$open()
remDr$navigate("https://fbref.com/en/players/7155e3e1/scout/365_euro/Pape-Gueye-Scouting-Report")
remDr$screenshot(display = TRUE)
library(dplyr)
stats = xml2::read_html(remDr$getPageSource()[[1]]) %>% rvest::html_nodes("#scout_full_MF") %>% rvest::html_table()
stats = stats[[1]]
names(stats) <- stats[1,]
stats <- stats[-1,]
stats <- stats[-which(stats == ""), ]
str(stats)
View(stats)
library(janitor)
stats <- clean_names(stats)

stats <- subset(stats, statistic != "Statistic"&
                             statistic != "Shooting" &
                            statistic !="Passing" &
                            statistic != "Pass Types"& 
                            statistic != "Goal and Shot Creation"&
                            statistic !="Defense" &
                            statistic != "Possession"&
                            statistic !="Miscellaneous Stats")
View(stats)
stats_final <- stats[-c(1:11),]
View(stats_final)

#set stats values
Shots_Total = stats_final[2,'percentile']
Pass_Comp_Short = stats_final[23,'percentile']
Pass_Comp__Medium = stats_final[26,'percentile']
Pass_Comp_Long = stats_final[29,'percentile']
SCA_PassLive = stats_final[63,'percentile']
Tackles_Won = stats_final[77,'percentile']
Dribbled_Past = stats_final[84,'percentile']
Pressures = stats_final[85,'percentile']
Pressures_Mid_3rd = stats_final[89,'percentile']
Pressures_Att_3rd = stats_final[90,'percentile']
Passes_Blocked = stats_final[94,'percentile']
Interceptions = stats_final[95,'percentile']
Tkl_Int = stats_final[96,'percentile']
Clearances = stats_final[97,'percentile']
Errors = stats_final[98,'percentile']


Pape_Gueye <- data.frame(row.names= "Pape Gueye" ,Shots_Total,Pass_Comp_Short,Pass_Comp__Medium,
                              Pass_Comp_Long, SCA_PassLive,Tackles_Won,Dribbled_Past,Pressures,
                        Pressures_Mid_3rd,Pressures_Att_3rd,Passes_Blocked,Interceptions,Tkl_Int,
                        Clearances, Errors)


Pape_Gueye <- mutate_if(Pape_Gueye ,is.character,as.numeric)

View(Pape_Gueye )

# Define the variable ranges: maximum and minimum
max_min <- data.frame(
  Shots_Total = c(100, 0), Pass_Comp_Short = c(100, 0), Pass_Comp__Medium = c(100, 0),
  Pass_Comp_Long = c(100, 0), SCA_PassLive = c(100, 0), Tackles_Won = c(100, 0),
  Dribbled_Past = c(100, 0), Pressures = c(100, 0), Pressures_Mid_3rd = c(100, 0),
  Pressures_Att_3rd = c(100,0),Passes_Blocked = c(100,0), Interceptions = c(100,0),
  Tkl_Int = c(100,0) , Clearances = c(100,0) , Errors = c(100,0)) 
rownames(max_min) <- c("Max", "Min")

# Bind the variable ranges to the data
Pape_Gueye  <- rbind(max_min, Pape_Gueye )
Pape_Gueye

library(fmsb)

Pape_Gueye_plot <- Pape_Gueye[c("Max", "Min", "Pape Gueye"), ]
radarchart(Pape_Gueye_plot)


# create_beautiful_radarchart <- function(data, color = "#00AFBB", 
#                                         vlabels = colnames(data), vlcex = 0.7,
#                                         caxislabels = NULL, title = NULL, ...){
#   radarchart(
#     data, axistype = 1,
#     # Customize the polygon
#     pcol = color, pfcol = scales::alpha(color, 0.5), plwd = 2, plty = 1,
#     # Customize the grid
#     cglcol = "grey", cglty = 1, cglwd = 0.8,
#     # Customize the axis
#     axislabcol = "grey", 
#     # Variable labels
#     vlcex = vlcex, vlabels = vlabels,
#     caxislabels = caxislabels, title = title, ...
#   )
# }

op <- par(mar = c(1, 2, 2, 1))
create_beautiful_radarchart(Pape_Gueye_plot, caxislabels = c(0, 25, 50, 75, 100))
legend(
  x = "center", legend = rownames(Pape_Gueye[-c(1,2),]), horiz = TRUE,
  bty = "n", pch = 20 , col = c("#00AFBB"),
  text.col = "black", cex = 1, pt.cex = 1.5
)
par(op)



library(readxl)
library(sf)
library(mapview)

data<-read_xlsx("C:/Users/glane/Downloads/Training Data for Ag Project.xlsx")
View(data)
locations_sf <- st_as_sf(data, coords = c("Longitude", "Latitude"), crs = 4326)
mapview(locations_sf)



data %>% group_by(Variety) %>% filter(n()>50)


anyNA(data1)
Percentage_missing=round(colSums(is.na(data1[,colnames(data1)[colSums(is.na(data1))>0]]))/nrow(data1)*100,2)
data.frame(MissingProportion=sort(Percentage_missing, decreasing = TRUE))

#Finding variable names with more than 30% missing values
Variables_with_High_NAs=colnames(data1)[colSums(is.na(data1))/nrow(data1)>0.3]

#Removing the variables with more than 30% missing values from the original dataset
data1=data1[,!names(data1)%in%Variables_with_High_NAs]

data1<-na.omit(data)

#Find Variety count per location
library(dplyr)
Variety_count <- data %>%
  count(Location, Variety,sort = TRUE ) 
View(Variety_count)


#Pattern for 2 weathers
library(ggplot2)
ggplot(data=data,aes(x=Weather1))+geom_density()
ggplot(data=data,aes(x=Weather2))+geom_density()


#Distribution of Yield Variables
ggplot(data = data,aes(y=Commercial_Yield,x=Variety_Yield,col=Yield_Difference))+geom_point()


###Finding highly correlated variables
Numeric=Filter(is.numeric,data1)
library(corrplot)
M=cor(na.omit(Numeric))
corrplot(M, method = "circle", type = "lower", 
         tl.srt = 45, tl.col = "black", tl.cex = 0.75)

#From the plot u can see the Temperature variables are highly correlated variables that are considered to remove multicollinearity


#Using logistic regression
LGM1=lm(Variety_Yield~. , data = data1)
summary(LGM1)

names(data1)
#Removing variable CE and Yield_difference since it gives NAs

Pred=predict(LGM1, data1, type = "response")
Pred

L=data.frame(LogOfOdds=round(exp(coef(LGM1)),4))
L$Variable=row.names(L)
row.names(L)=NULL
L=L[,c(2,1)]
L%>%arrange(desc(LogOfOdds))%>%filter(LogOfOdds>=1)%>%mutate(Probability=round(LogOfOdds/(1+LogOfOdds),3))


library(readxl)
data_growth<-read_xlsx("C:/Users/glane/Downloads/Pilot Experiment.xlsx",1)
View(data_growth)
data_biomass <- read_xlsx("C:/Users/glane/Downloads/Pilot Experiment.xlsx",2)
View(data_biomass)
data_biomass<-data_biomass[-c(40:1005),-c(14:25)]
data_growth <- filter(data_growth, COH != "na" & Meat1 != "na")
data_growth$Meat1 <- as.numeric(data_growth$Meat1)
data_growth$COH <- as.numeric(data_growth$COH)
data_biomass <- na.omit(data_biomass)
str(data_growth)
str(data_biomass)

data_new <- merge(data_growth,data_biomass,all = TRUE)
View(data_new)
data_new[is.na(data_new)]<-0
data_new <-subset(data_new,select = -Day)
cor(data_new)


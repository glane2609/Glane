data<-read.csv("C:/Users/Glane/Downloads/Assignment2Question3Data.csv")
View(data)
str(data)


#Converting categorical to factor
data$sex <- factor(data$sex,levels = c(1,2),labels = c("female","male"))
data$died <- factor(data$died,levels = c(1,2),labels = c("died","survived"))
data$intubed <- factor(data$intubed,levels = c(1,2),labels = c("Yes","No"))
data$pneumonia <- factor(data$pneumonia,levels = c(1,2),labels = c("Yes","No"))
data$pregnancy <- factor(data$pregnancy,levels = c(1,2),labels = c("Yes","No"))
data$copd <- factor(data$copd,levels = c(1,2),labels = c("Yes","No"))
data$diabetes <- factor(data$diabetes,levels = c(1,2),labels = c("Yes","No"))
data$asthma <- factor(data$asthma,levels = c(1,2),labels = c("Yes","No"))
data$inmsupr <- factor(data$inmsupr,levels = c(1,2),labels = c("Yes","No"))
data$hypertension <- factor(data$hypertension,levels = c(1,2),labels = c("Yes","No"))
data$other_disease <- factor(data$other_disease,levels = c(1,2),labels = c("Yes","No"))
data$cardiovascular <- factor(data$cardiovascular,levels = c(1,2),labels = c("Yes","No"))
data$obesity <- factor(data$obesity,levels = c(1,2),labels = c("Yes","No"))
data$renal_chronic <- factor(data$renal_chronic,levels = c(1,2),labels = c("Yes","No"))
data$tobacco <- factor(data$tobacco,levels = c(1,2),labels = c("Yes","No"))
data$contact_other_covid <- factor(data$contact_other_covid,levels = c(1,2),labels = c("Yes","No"))
data$covid_res <- factor(data$covid_res,levels = c(1,2,3),labels = c("Yes","No","Pending"))
data$icu <- factor(data$icu,levels = c(1,2),labels = c("Yes","No"))

data<-data[complete.cases(data), ]

#Logit model
model <- glm(died~pneumonia+pregnancy+diabetes+asthma+obesity+tobacco,data = data, family = "binomial")
summary(model)

data$prediction <- predict(model, data, type = "response") > 0.5
View(data)

#compare predictions
data$prediction == data$died

#calculate overall accuracy of model
ACC <- sum(data$prediction == data$died) /
  length(data$prediction)
ACC

#False Positive Rate
# 2 means
data$died <- factor(data$died,levels = c("died","survived"),labels =c(1,2))
data$died
data$prediction <- factor(data$prediction,levels = c("TRUE","FALSE"),labels =c(1,2))
Step1 <- sum(data$prediction == 1 & data$died == 2)
RealNeg <- sum(data$died == 2)
RealNeg
FP <- Step1/RealNeg
FP 

#False Negative rate ~29%

Step1 <- sum(data$prediction == 2 & data$died == 1)
RealPos <- sum(data$died == 1)

FN <- Step1/RealPos
FN
#PP

Step1 <- sum(data$prediction == 1 & data$died == 2)
totalAlive <- sum(data$prediction == 1)

PPV <- Step1/totalAlive
PPV

library(ggplot)
qplot(age,colour = died , data = data , geom = "density" , xlab = "Ages", ylab = "Rate" , main = "Age wise died vs survived")

options("scipen"=9999)
library(plyr)
library(readr)
data <- list.files("C:/Users/glane/Downloads/bhavcopy",pattern = "*.csv",full.names = TRUE)
View(data)
dat_csv = ldply(data , read_csv)
View(dat_csv)
dat_csv <- dat_csv[,-14]
View(dat_csv)
library(dplyr)
library(lubridate)
dat_csv$TIMESTAMP <- dmy(dat_csv$TIMESTAMP)
str(dat_csv)
dat_csv <- subset(dat_csv,SERIES=="EQ")
dat_csv <- select(dat_csv,SYMBOL,SERIES,CLOSE,TIMESTAMP)
# data_csv<- dat_csv %>% filter(between(TIMESTAMP, as.Date("2021-04-22") , as.Date("2021-05-21") ))
# View(data_csv)
dat_csv$TIMESTAMP<-  dat_csv$TIMESTAMP[order(as.Date( dat_csv$TIMESTAMP, format="%d/%m/%Y"))]
dat_csv <- dat_csv[order(as.Date(dat_csv$TIMESTAMP, format="%d/%m/%Y")), ]
str(dat_csv)
View(dat_csv)
dat_csv2 <- filter(dat_csv,SYMBOL=="ADANIGREEN" | SYMBOL=="BEL" | SYMBOL == "SBIN" | SYMBOL== "SIEMENS" | SYMBOL == "RELIANCE" |
                     SYMBOL == "HDFCBANK" | SYMBOL=="BPCL" | SYMBOL== "DABUR" | SYMBOL== "BOSCHLTD" | SYMBOL=="TATASTEEL")
View(dat_csv2)
D <- dat_csv2%>% group_by(SYMBOL) %>% summarise(diff=diff(CLOSE))
View(D)


View(lag(dat_csv2$TIMESTAMP))
final <- ifelse(D$diff <= 1 , "YES" , "NO")
View(final)

trade <- cbind(D,final,dat_csv2)
names(trade)[3] <- "YES_NO"
write.csv(trade,"trade.csv")

write.csv(dat_csv2,"dat.csv")

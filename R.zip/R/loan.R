data<- readRDS("C:/Users/glane/Downloads/loan_data.rds")
View(na.omit(data))
class(data)

library(caTools)  
set.seed(1234)
sample.split(data$loan_default,SplitRatio = 0.65)-> split_tag
subset(data, split_tag==T)->train
subset(data, split_tag==F)->test

nrow(train)
nrow(test)

glm(loan_default~loan_amount+installment+interest_rate+loan_purpose+application_type+term+homeownership+annual_income+current_job_years+debt_to_income+total_credit_lines+years_credit_history+missed_payment_2_yr+history_bankruptcy+history_tax_liens, data=train, family = "binomial")-> mod_log
summary(mod_log)
predict(mod_log,newdata=test,type="response")->result_log
head(result_log)
range(result_log)

#Confusion Matrix
table(test$loan_default, result_log>0.1)

library(ROCR)

prediction(result_log,test$loan_default) -> predict_log
performance(predict_log,"acc")->acc
plot(acc)

table(test$loan_default, result_log>0.41)
performance(predict_log,"tpr","fpr") -> roc_curve
plot(roc_curve)
plot(roc_curve, colorize=T)

performance(predict_log,"auc")->auc.tmp
auc<- auc.tmp@y.values
auc

#Summary Table
library(dplyr)
default_rates <- data %>% group_by(loan_purpose) %>%
  summarise(n_customers = n(),
            customers_default = sum(loan_default == "yes"),
            default_percent = 100 * mean(loan_default == "yes"))

library(ggplot2)
ggplot(data = default_rates, mapping = aes(x = loan_purpose, y = default_percent)) +
  geom_bar(stat = "identity", fill = "#006EA1", color = "white") +
           labs(title = "Loan Default Rate by Purpose of Loan",
                x = "Loan Purpose",
                y = "Default Percentage") +
             theme_light()
           

#Summary Table for loan

data %>% group_by(loan_amount) %>% summarise(n_customers = n(),
                                                    customers_default = sum(loan_default == "yes"),
                                                    default_percent = 100 * mean(loan_default == "yes"))



#To distribution of the loan amount using histogram according to the type of loan_default
ggplot(data=data,aes(loan_amount, col=loan_default))+
  geom_histogram(bins=40) + 
  facet_grid(loan_default ~ .)


#Summarise loan_amount wrt homeownership

data %>% group_by(homeownership) %>% summarise(loan_amount)
   
#To examine the distribution of loan amount according to ownership of house                                                                                     
ggplot(data=data, aes(homeownership,loan_amount,fill=homeownership))+geom_boxplot(outlier.color = "blue")+labs(title="Box plot of loan amount")


#Summarise loan amount wrt term

data %>% group_by(term) %>% summarise(loan_amount)

#To distribution of the loan amount using density plot according to the type of term
data %>% group_by(term) %>% summarise(loan_amount)
ggplot(data=data,aes(loan_amount, fill=term))+
  geom_density(alpha=0.25) + 
  facet_grid(term ~ .)



#2. 

3. Are there differences in loan default rates by loan purpose?
#Answer : Yes, the data indicates that credit card and medical loans have significantly l arger default rates
#than any other type of loan. In fact, both of these loan types have default rates at more than 50%. This is
#nearly two times the average default rate for all other loan types.



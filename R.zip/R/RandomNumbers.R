del_p<- (1-0)/100
N<- 100
M<- 50
for(i in 1:100){
  del_p <- rbinom(50, size=100, prob=.3)  
}
del_p

rangeP <- seq(0, 1 , length.out = 1000)
plot(rangeP, dbinom(x = 50, prob = rangeP, size = 100),
     type = "l", xlab = "P(Black)", ylab = "Density")
#Prior
lines(rangeP, dnorm(x = rangeP, mean = .5, sd = .1) / 15,
      col = "red")

lik <- dbinom(x = 50, prob = rangeP, size = 100)
prior <- dnorm(x = rangeP, mean = .5, sd = .1)
lines(rangeP, lik * prior, col = "green")

unstdPost <- lik * prior
stdPost <- unstdPost / sum(unstdPost)
lines(rangeP, stdPost, col = "blue")
legend("topleft", legend = c("Likelihood", "Prior", "Unstd Post", "Post"),
       text.col = 1:4, bty = "n")




#To remove NA's (missing values denoted with NA) from the data
data <- na.omit(data)

#To split the data into train and test with any split ratio of your choice
#Here we're splitting the data on the selling price which is our dependent variable
sample.split(data$SellingPrice,SplitRatio = 0.70)-> split_tag
subset(data, split_tag==T)->train
subset(data, split_tag==F)->test
nrow(train)
nrow(test)

#Running multiple linear regression model on trained data
lm(SellingPrice~Region+Type+NaturalLight+AnnualCrimeRate+Garage+ElemSchoolRatings+Rental+LotCost,data=train)-> model
summary(model)
par(mfrow=c(2,2))
plot(model)
#Predict the model based on test data
predict(model, newdata=test)->predicted_multi_linear
head(predicted_multi_linear)
View(predicted_multi_linear)
#You'll get 5 random predicted values of selling price via head function 
#You can also use View function to view the whole predicted values

#combine the actual values of selling price with the predicted ones
cbind(Actual=test$SellingPrice, Predicted=predicted_multi_linear)-> final_data
as.data.frame(final_data)->final_data
class(final_data)
head(final_data)

#This helps us in getting the error ( difference) in price value
final_data$Actual - final_data$Predicted ->error
View(error)

#Predicted vs error plot
ggplot(data= final_data, aes(x=Predicted, y=error)) + geom_point()

#Q-Q plot
qqnorm(final_data$error)

ncvTest(model)
spreadLevelPlot(model)

influencePlot(model, scale=10,  
              xlab="Hat-Values", ylab="Studentized Residuals", id=TRUE)

vif(model) 

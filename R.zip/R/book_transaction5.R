
rm(list=ls())
library(data.table)
#install.packages("dplyr")
library(dplyr)
#install.packages("pROC")
library("pROC")

data = fread("C:/Users/glane/Downloads/book_transaction.csv")

# understand the data
head(data)
str(data)

summary(data)

data[, DATE:=as.Date(DATE,format="%m/%d/%Y")] 

#split the data into calibration and validation samples at 9/30/17
data.calibration<-data[DATE<=as.Date(c("2017-09-30")),]
data.validation<-data[DATE>as.Date(c("2017-09-30")),]

# create new data frames that aggregate info at per ID level
# monetary = average spend
# frequency = number of separate orders
# lastpurchase = date of most recent purchase
# numBOOKS = average number of BOOKS ordered

new.calibration <- data.calibration[,list(monetary=mean(DOLLARS),
                                          frequency=length(DOLLARS),
                                          lastpurchase=as.Date(max(DATE)),
                                          recency=as.numeric(max(data.calibration$DATE)-max(DATE)),
                                          numbooks=sum(BOOKS)),
                                    by=.(ID)]

new.validation <- data.validation[,list(monetary=mean(DOLLARS),
                                        frequency=length(DOLLARS),
                                        lastpurchase=as.Date(max(DATE)),
                                        recency=as.numeric(max(data.validation$DATE)-max(DATE)),
                                        numbooks=sum(BOOKS)),
                                  by=.(ID)]

#Merge calibration and validation samples into wide format where NAs in the validation indicate not being retained
new<-merge(new.calibration, new.validation, by = c("ID"), all.x = TRUE)

#creates another column which returns a 1 if customer purchases in the validation period, 0 otherwise
new[,retained:=as.numeric(!is.na(monetary.y))]

#Linear regression
linearfit <-lm(retained ~ recency.x + frequency.x + monetary.x, data=new)
summary(linearfit)
new[, linearprob := predict(linearfit, type="response")]
summary(new$linearprob)
new[, plot(sort(linearprob,decreasing = T))]

new[, linearPred:= ifelse(linearprob>=0.5, 1, 0)]
head(new)
new[, table(retained, linearPred)]

View(new)

data.roc = new[, roc(retained, linearprob, percent=T)]
auc(data.roc)
plot(data.roc,smooth=T)
coords(data.roc,"best","specificity",transpose = F)

new[, linearPred := ifelse(linearprob>=0.1048957, 1, 0)]
head(new)
new[, table(retained, linearPred)]

# using Logistic Regression 
logitfit = glm(retained ~ recency.x + frequency.x + monetary.x, data=new, family=binomial(link="logit"))
summary(logitfit)
            
new[, logitProb := predict(logitfit,type="response")]
head(new)
summary(new$logitProb)

new[, plot(sort(logitProb,decreasing = T))]

new[, logitPred:= ifelse(logitProb>=0.5, 1, 0)]
head(new)
new[, table(retained, logitPred)]

View(new)

data.roc1 = new[, roc(retained, logitProb, percent=T)]
auc(data.roc1)
plot(data.roc1,smooth=T)
coords(data.roc1,"best","specificity",transpose = F)

new[, logitPred := ifelse(logitProb>=0.1048957, 1, 0)]
head(new)
new[, table(retained, logitPred)]

#Monetary prediction for Logistic regression
monetaryprediction1 = expand.grid(recency.x=mean(new$recency.x),
                                  frequency.x=mean(new$frequency.x),
                                  monetary.x=seq(min(new$monetary.x),max(new$monetary.x)))
monetaryprediction1$fit <- predict(logitfit, monetaryprediction1,type="response")
plot(monetaryprediction1$monetary.x,monetaryprediction1$fit,col=3)
abline(lm(logitProb~monetary.x,data=new),col=2);

#Frequency prediction for Logistic regression
Frequencyprediction1 = expand.grid(recency.x=mean(new$recency.x),
                                   frequency.x=seq(min(new$frequency.x),max(new$frequency.x)),
                                   monetary.x=mean(new$monetary.x))
Frequencyprediction1$fit <- predict(logitfit, Frequencyprediction1,type="response")
plot(Frequencyprediction1$frequency.x,Frequencyprediction1$fit,col=3)
abline(lm(logitProb~frequency.x,data=new),col=2);

#Recency prediction for Logistic regression
Recencyprediction1 = expand.grid(recency.x=seq(min(new$recency.x),max(new$recency.x)),
                                 frequency.x=mean(new$frequency.x),
                                 monetary.x=mean(new$monetary.x))
Recencyprediction1$fit <- predict(logitfit, Recencyprediction1,type="response")
plot(Recencyprediction1$recency.x,Recencyprediction1$fit ,col=3)
abline(lm(logitProb~recency.x,data=new),col=2);




#Decile analysis

new = mutate(new, quantile_rank_monetary = ntile(desc(new$monetary.x),10),quantile_rank_frequency = ntile(desc(new$frequency.x),10),quantile_rank_recency = ntile(desc(new$recency.x),10))


#Percent retention
new %>%
  group_by(quantile_rank_monetary,quantile_rank_recency,quantile_rank_frequency) %>%
  summarise(n = n()) %>%
  mutate(pct = n / sum(n)*100)

recency = new[, list(n.retained=sum(retained),
                      n=length(retained),
                      rate_observed=sum(retained)/length(retained),
                      rate_predicted=mean(logitProb)),
               by=.(quantile_rank_recency)][order(quantile_rank_recency)]
recency

frequency = new[, list(n.retained=sum(retained),
                     n=length(retained),
                     rate_observed=sum(retained)/length(retained),
                     rate_predicted=mean(logitProb)),
              by=.(quantile_rank_frequency)][order(quantile_rank_frequency)]
frequency

monetary = new[, list(n.retained=sum(retained),
                       n=length(retained),
                       rate_observed=sum(retained)/length(retained),
                       rate_predicted=mean(logitProb)),
                by=.(quantile_rank_monetary)][order(quantile_rank_monetary)]
monetary

recency[,plot(order(-quantile_rank_recency),rate_observed,type="b", xlab="order(quantile_rank_recency)" ,ylab="rate_observed")]
frequency[,plot(order(quantile_rank_frequency),rate_observed,type="b", xlab="order(quantile_rank_frequency)" ,ylab="rate_observed")]
monetary[,plot(order(quantile_rank_monetary),rate_observed,type="b", xlab="order(quantile_rank_monetary)" ,ylab="rate_observed")]


plot(recency$logitProb_quantile, y, main="title", sub="subtitle",
     xlab="X-axis label", ylab="y-axix label",
     xlim=c(xmin, xmax), ylim=c(ymin, ymax))

# here n is basically summarise the count of rank of each variable mentioned in percent retention 
# for eg rank 1 in quantile_rank_monetary, quantile_rank_recency, quantile_rank_frequency occurs 76 times

#Random
new[,logitProb_quantile:=ntile(logitProb,10)]
new[,table(logitProb_quantile)]
targeted = new[, list(n.retained=sum(retained),
                      n=length(retained),
                      rate_observed=sum(retained)/length(retained),
                      rate_predicted=mean(logitProb)),
               by=.(logitProb_quantile)]
targeted

targeted_recency = new[, list(n.recency=sum(recency.x),
                      n=length(recency.x),
                      rate_observed=sum(recency.x)/length(recency.x),
                      rate_predicted=mean(logitProb)),
               by=.(logitProb_quantile)]
targeted_recency



#Q.4 A
#cumulative lift chart for Recency
setorder(targeted_recency,-logitProb_quantile)
targeted_recency
targeted_recency[,cumlift_recency:=(cumsum(n.recency)/cumsum(n))/(sum(n.recency)/sum(n))] 
targeted_recency[,cumcustomerpt_recency:=cumsum(n)/sum(n)]
targeted_recency
targeted_recency[, plot(cumlift_recency,rev(cumcustomerpt_recency),type="b")]



#Q.4 B

targeted[,cumlift:=(cumsum(n.retained)/cumsum(n))/(sum(n.retained)/sum(n))]
targeted
targeted = targeted[order(-logitProb_quantile),]
targeted
targeted[,plot(order(-logitProb_quantile),rate_predicted,type="b")]


#Q.4.C
# random selection vs. targeting

#Random
targeted[,cumlift:=(cumsum(n.retained)/cumsum(n))/(sum(n.retained)/sum(n))]
targeted

#Target
targeted = targeted[order(-logitProb_quantile),]
targeted
targeted[,plot(order(-logitProb_quantile),rate_predicted,type="b")]

targeted[,cumcustomerpt:=cumsum(n)/sum(n)]
targeted

#We can see that for random we get lift of 0.4250496 and for target we get lift of 1.4032304

#Q.4.D
# Gain chart
setorder(targeted,-logitProb_quantile)

targeted[,gains:=(cumsum(n.retained)/sum(n.retained))] 
targeted[,cumcustomerpt:=cumsum(n)/sum(n)]
targeted
targeted[, plot(cumcustomerpt,gains,type="b",ylim=c(0,1),xlim=c(0,1),main="gain chart")]; abline(h=100, col="blue")



#Q.4.E
#Gain

targeted[,gains:=(cumsum(n.retained)/sum(n.retained))] 
targeted[,cumcustomerpt:=cumsum(n)/sum(n)]
targeted
targeted[, plot(cumcustomerpt,gains,type="b",ylim=c(0,1),xlim=c(0,1),main="gain chart")]; abline(h=100, col="blue")


#Q.4.F
#The gain plot for variable frequency.x shows 0 gain till 70% population and then increases with 100% stability whereas lift starts decreasing from 10 to 1
targeted_frequency = new[, list(n.frequency=sum(frequency.x),
                              n=length(frequency.x),
                              rate_observed=sum(frequency.x)/length(frequency.x),
                              rate_predicted=mean(logitProb)),
                       by=.(logitProb_quantile)]
targeted_frequency

targeted_frequency[,gains_freq:=(cumsum(n.frequency)/sum(n.frequency))] 
targeted_frequency[,cumcustomerpt_freq:=cumsum(n)/sum(n)]
targeted_frequency
targeted_frequency[, plot(cumcustomerpt_freq,gains_freq,type="b",ylim=c(0,1),xlim=c(0,1),main="gain chart")]; abline(h=100, col="blue")


#The below code gives you idea about retained customers
targeted[,cumcustomerpt:=cumsum(n)/sum(n)]
targeted

#Around 80% customers are retained by capturing on 10% of customers



library(readxl)
getwd()
setwd("C:\\Users\\glane\\Downloads\\")
data<-read_xlsx("gk.xlsx")
View(data)
library(ggplot2)
library(dplyr)
library(ggrepel)
data <- filter(data,Comp=="eng Premier League")
d<-ggplot(data = data,aes(y=crosses_stopped_by_gk,x= minutes_played_divide_by_90,
))+geom_point()+ geom_text_repel(aes(label=Player),hjust=1.0,vjust=1.0)
d

library(gganimate) #for animating your plot
library(scales) # for scaling your x or y-axis 

animateplot <- d + transition_time(minutes_played_divide_by_90) +
  shadow_mark() + scale_x_continuous(limits = c(0,35)) + 
  xlab("minutes_played_divide_by_90") + ylab("crosses_stopped_by_gk")
animate(animateplot, width = 700, height = 500)

#ifelse(number_of_defensive_actions_outside_penalty_area>500,as.character

library(prophet)
library(dplyr)
library(ggplot2)
library(readxl)
library(lubridate)
data<-read_xlsx("C:/Users/glane/Downloads/Mr.Wheel.xlsm")
View(data)

data1<- select(data , Date , Volume_cubicyards)
str(data1)
data1< - as.numeric(data1$Date)
View(data1)
data1$Date <- ymd(data1$Date)
str(data1)
qplot(Date, Volume_cubicyards , data = data1)
a<-as.Date(data1$Date , format = '%d-%m-%y')
a<-as.data.frame(a)
b<-data1$Volume_cubicyards
b <- as.data.frame(b)
Volume<- mutate(a,b)
View(Volume)
colnames(Volume) <- c("Date" , "value")
Volume$Date <- ymd(Volume$Date)
str(Volume)
qplot(Date, value , data = Volume)
ds <- Volume$Date
y <-  Volume$value
df<- data.frame(ds,y)
as.Date(df$ds , format = '%Y-%m-%d')
str(df)
df<- na.omit(df)
View(df)

#Forecasting
m <- prophet(df)

#Prediction
future <- make_future_dataframe(m , periods = 1000 )
View(future)
forecast<- predict(m, future)

#plot forecast
dyplot.prophet(m,forecast)


#Weight
data2<- select(data , Date , Weight_tons)
str(data2)
data2< - as.numeric(data2$Date)
View(data2)
data2$Date <- ymd(data2$Date)
str(data2)
qplot(Date, Weight_tons , data = data2)
a1<-as.Date(data2$Date , format = '%d-%m-%y')
a1<-as.data.frame(a1)
b1<-data2$Weight_tons
b1 <- as.data.frame(b1)
weight_ton<- mutate(a1,b1)
View(weight_ton)
colnames(weight_ton) <- c("Date" , "value")
weight_ton$Date <- ymd(weight_ton$Date)
str(weight_ton)
qplot(Date, value , data = weight_ton)
ds <- weight_ton$Date
y <-  weight_ton$value
df<- data.frame(ds,y)
as.Date(df$ds , format = '%Y-%m-%d')
str(df)
df1<- na.omit(df)
View(df1)

#Forecasting
m1 <- prophet(df1)

#Prediction
future1 <- make_future_dataframe(m1 , periods = 1000 )
View(future1)
forecast1<- predict(m1, future1)

#plot forecast
plot(m1,forecast1)
dyplot.prophet(m1,forecast1)


#HomesPowered
data3<- select(data , Date , HomesPowered)
str(data3)
data3< - as.numeric(data3$Date)
View(data3)
data3$Date <- ymd(data3$Date)
str(data3)
qplot(Date, HomesPowered , data = data3)
a2<-as.Date(data3$Date , format = '%d-%m-%y')
a2<-as.data.frame(a2)
b2<-data3$HomesPowered
b2 <- as.data.frame(b2)
HomesPowered<- mutate(a2,b2)
View(HomesPowered)
colnames(HomesPowered) <- c("Date" , "value")
HomesPowered$Date <- ymd(HomesPowered$Date)
str(HomesPowered)
qplot(Date, value , data = HomesPowered)
ds <- HomesPowered$Date
y <-  HomesPowered$value
df2<- data.frame(ds,y)
as.Date(df2$ds , format = '%Y-%m-%d')
str(df2)
df2<- na.omit(df2)
View(df2)

#Forecasting
m2 <- prophet(df2)

#Prediction
future2 <- make_future_dataframe(m2 , periods = 1000 )
View(future2)
forecast2<- predict(m2, future2)

#plot forecast
plot(m2,forecast2)
dyplot.prophet(m2,forecast2)



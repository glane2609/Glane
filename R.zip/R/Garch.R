library(rugarch)
library(readxl)
wheat <- read_excel("C:/Users/glane/Downloads/wheat.xlsx")

Logret1 <- wheat$Logret
head(Logret1)
January<-read_excel("C:/Users/glane/Downloads/wheat_jan.xlsx")
Logret2 <- January$Logret
head(Logret2)

wheat1 <- ugarchspec(variance.model=list(model ="sGARCH",garchOrder = c(1,1)),mean.model=list(armaOrder=c(0,0)),distribution.model= "std")
#applying it to the data
wheatGarch1<-ugarchfit(spec = wheat1 , data = Logret1)
wheatGarch1

#Armaorder 1,1
wheat2 <- ugarchspec(variance.model=list(model ="sGARCH",garchOrder = c(1,1)),mean.model=list(armaOrder=c(1,1)),distribution.model= "std")
#applying it to the data
wheatGarch2<-ugarchfit(spec = wheat2 , data = Logret1)
wheatGarch2

#Predict and plot
WheatPredict<-ugarchboot(wheatGarch1, n.ahead = 10,method = c("Partial","Full")[1])
plot(WheatPredict,which = 2)

#Wheat_jan
January1 <- ugarchspec(variance.model=list(model ="sGARCH",garchOrder = c(1,1)),mean.model=list(armaOrder=c(0,0)),distribution.model= "std")
JanuaryGarch1<-ugarchfit(spec = January1 , data = Logret2)
JanuaryGarch1
#Predict and plot
JanuaryPredict<-ugarchboot(JanuaryGarch1, n.ahead = 21,method = c("Partial","Full")[1])
plot(JanuaryPredict,which = 2)
ugarc


  
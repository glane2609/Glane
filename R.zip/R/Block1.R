#Question1
N <- readline(prompt="Enter Number: ")
a<-print(sample(50:100, replace = TRUE))
min(a)
max(a)

#Question2
# Creating Vectors 
vec1 <- c(1, 2, 3) 
vec2 <- c(3,4,5,6) 

# Creating a list of Vectors 
listt = list(vec1, vec2) 
# Printing List 
print (listt) 
#merging 
list_merge = append(vec1 , vec2)
# Printing list_merge
print(list_merge)
unique(list_merge)
#Sorting
list1 = sort(list_merge , decreasing = TRUE)
list1

#Question3
# Elements are arranged sequentially by row.
M <- matrix(c(1:9), nrow = 3, byrow = TRUE)
print(M)
#Ascending order
M[order(M[,1],decreasing=FALSE),]

#Question4
# take input from the user
nterms = as.integer(readline(prompt="How many terms? "))
# first two terms
n1 = as.integer(readline(prompt="Enter number greater than 5: "))
n2 = as.integer(readline(prompt="Enter number less than 150: "))
count = 1
# check if the number of terms is valid
if(nterms <= 0) {
  print("Plese enter a positive integer")
} else {
  if(nterms == 1) {
    print("Fibonacci sequence:")
    print(n1)
  } else {
    print("Fibonacci sequence:")
    print(n1)
    print(n2)
    while(count < nterms) {
      nth = n1 + n2
      print(nth)
      # update values
      n1 = n2
      n2 = nth
      count = count + 1
    }
  }
}

#Question5
Names=c("John" , "Mark" , "Luke")
Names
#Height in cm
Height = c(175 , 166 , 178)
Height

#Weight in kg
Weight = c(75 ,80 , 85)
Weight

list2 <- c(Names , Height , Weight)
sort1 <- sort(list2 , decreasing = FALSE)
sort1


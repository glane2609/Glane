
rm(list=ls())
library(data.table)
#install.packages("dplyr")
library(dplyr)
#install.packages("pROC")
library("pROC")

data = fread("C:/Users/glane/Downloads/book_transaction.csv")

# understand the data
head(data)
str(data)

summary(data)

data[, DATE:=as.Date(DATE,format="%m/%d/%Y")] 

#split the data into calibration and validation samples at 9/30/17
data.calibration<-data[DATE<=as.Date(c("2017-09-30")),]
data.validation<-data[DATE>as.Date(c("2017-09-30")),]

# create new data frames that aggregate info at per ID level
# monetary = average spend
# frequency = number of separate orders
# lastpurchase = date of most recent purchase
# numBOOKS = average number of BOOKS ordered

new.calibration <- data.calibration[,list(monetary=mean(DOLLARS),
                                          frequency=length(DOLLARS),
                                          lastpurchase=as.Date(max(DATE)),
                                          recency=as.numeric(max(data.calibration$DATE)-max(DATE)),
                                          numbooks=sum(BOOKS)),
                                    by=.(ID)]

new.validation <- data.validation[,list(monetary=mean(DOLLARS),
                                        frequency=length(DOLLARS),
                                        lastpurchase=as.Date(max(DATE)),
                                        recency=as.numeric(max(data.validation$DATE)-max(DATE)),
                                        numbooks=sum(BOOKS)),
                                  by=.(ID)]

#Merge calibration and validation samples into wide format where NAs in the validation indicate not being retained
new<-merge(new.calibration, new.validation, by = c("ID"), all.x = TRUE)

#creates another column which returns a 1 if customer purchases in the validation period, 0 otherwise
new[,retained:=as.numeric(!is.na(monetary.y))]

#Linear regression
linearfit <-lm(retained ~ recency.x + frequency.x + monetary.x, data=new)
summary(linearfit)
new[, linearprob := predict(linearfit, type="response")]
summary(new$linearprob)
new[, plot(sort(linearprob,decreasing = T))]

new[, linearPred:= ifelse(linearprob>=0.5, 1, 0)]
head(new)
new[, table(retained, linearPred)]

# ROC curve
# y-axis is the sensitivity: the probability that the model predicts a response when customers actually respond (positive responses)
# x-axis is (100%-specificity)
# specificity refers to the % of predicted non-responses contained in the group of customers not selected by the model
# thus, a good model is the one with high sensitivity and low false positive rate (100%-specifity)

data.roc = new[, roc(retained, linearprob, percent=T)]
auc(data.roc)
plot(data.roc,smooth=T)
coords(data.roc,"best","specificity",transpose = F)

new[, linearPred := ifelse(linearprob>=0.1048957, 1, 0)]
head(new)
new[, table(retained, linearPred)]


# using Logistic Regression 
logitfit = glm(retained ~ recency.x + frequency.x + monetary.x, data=new, family=binomial(link="logit"))
summary(logitfit)
            

new[, logitProb := predict(logitfit,type="response")]
head(new)
summary(new$logitProb)

new[, plot(sort(logitProb,decreasing = T))]

new[, logitPred:= ifelse(logitProb>=0.5, 1, 0)]
head(new)
new[, table(retained, logitPred)]

data.roc1 = new[, roc(retained, logitProb, percent=T)]
auc(data.roc1)
plot(data.roc1,smooth=T)
coords(data.roc1,"best","specificity",transpose = F)

new[, logitPred := ifelse(logitProb>=0.1048957, 1, 0)]
head(new)
new[, table(retained, logitPred)]


#Monetary prediction for Logistic regression
monetaryprediction1 = expand.grid(recency.x=mean(new$recency.x),
                                  frequency.x=mean(new$frequency.x),
                                  monetary.x=seq(min(new$monetary.x),max(new$monetary.x)))
monetaryprediction1$fit <- predict(logitfit, monetaryprediction1,type="response")
plot(monetaryprediction1$monetary.x,monetaryprediction1$fit,col=3)


#Frequency prediction for Logistic regression
Frequencyprediction1 = expand.grid(recency.x=mean(new$recency.x),
                                   frequency.x=mean(new$frequency.x),
                                   monetary.x=seq(min(new$monetary.x),max(new$monetary.x)))
Frequencyprediction1$fit <- predict(logitfit, Frequencyprediction1,type="response")
plot(Frequencyprediction1$frequency.x,Frequencyprediction1$fit,col=3)


#Recency prediction for Logistic regression
Recencyprediction1 = expand.grid(recency.x=mean(new$recency.x),
                                 frequency.x=mean(new$frequency.x),
                                 monetary.x=seq(min(new$monetary.x),max(new$monetary.x)))
Recencyprediction1$fit <- predict(logitfit, Recencyprediction1,type="response")
plot(Recencyprediction1$recency.x,Recencyprediction1$fit ,col=3)



#Decile analysis

new = mutate(new, quantile_rank_monetary = ntile(desc(new$monetary.x),4),quantile_rank_frequency = ntile(desc(new$frequency.x),4),quantile_rank_recency = ntile(desc(new$recency.x),4))


#Percent retention
new %>%
  group_by(quantile_rank_monetary, quantile_rank_recency,quantile_rank_frequency) %>%
  summarise(n = n()) %>%
  mutate(pct = n / sum(n)*100)



# here n is basically summarise the count of rank of each variable mentioned in percent retention 
# for eg rank 1 in quantile_rank_monetary, quantile_rank_recency, quantile_rank_frequency occurs 76 times

#Q.4

library(funModeling)

#Q.4 A
#cumulative lift chart for Recency
gain_lift(data=new, score='quantile_rank_recency', target='recency.x')

#Q.4 B
gain_lift(data=new, score='logitProb_quantile', target='retained' )

# For Data = new ,the Cumulative Lift decreases as population % increases from 10 to 20 and so on


#Q.4.C
# random selection vs. targeting

new[,table(logitProb_quantile)]
targeted = new[, list(n.retained=sum(retained),
                      n=length(retained),
                      rate_observed=sum(retained)/length(retained),
                      rate_predicted=mean(logitProb)),
               by=.(logitProb_quantile)]
#Random
targeted[,cumlift:=(cumsum(n.retained)/cumsum(n))/(sum(n.retained)/sum(n))] 
targeted

#Targeting
targeted = targeted[order(-logitProb_quantile),]
targeted

targeted[,cumcustomerpt:=cumsum(n)/sum(n)]
targeted

#We can see that for random we get lift of 0.4250496 and for target we get lift of 1.4032304

#Q.4.D
gain_lift(data=new, score='logitProb_quantile', target='retained')

# Q. 4 b gives lift chart and Q.4.D gives gain chart

#Q.4.E
#Gain
library(funModeling)
gain_lift(data=new,score = 'logitProb_quantile',target = 'frequency.x')

#Q.4.F
#The gain plot for variable frequency.x shows 0 gain till 70% population and then increases with 100% stability whereas lift starts decreasing from 10 to 1

#The below code gives you idea about retained customers
targeted[,cumcustomerpt:=cumsum(n)/sum(n)]
targeted

#Around 80% customers are retained by capturing on 10% of customers

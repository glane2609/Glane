library(forecast)
library(tseries)
data<-read.csv("C:/Users/glane/Downloads/datanewc.csv",stringsAsFactors = FALSE)
library(lubridate)
View(data)
dmy(data$Date)
data_new <- ts(data$Withdrawals, frequency = 365 ,start = 1996)

plot(data_new, main = "Time Series of Withdrawls")

decomposed_data_new <- decompose(data_new, type = "additive")
plot(decomposed_data_new )

ggAcf(data_new, main='ACF for Differenced Series') 
ggPacf(data_new, main='PACF for Differenced Series') 


mod<-tslm(data_new~trend + season )
summary(mod)

autoplot(forecast(mod, h=120))

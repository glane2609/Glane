library(readxl)
data<-read_excel("C:/Users/glane/Downloads/GSS2012.xlsx"  )
View(data)

#Question1a
#Histogram
hist(data$RINCOME, breaks = 20000)

#Question1b
#DescriptiveStats
library(psych)

describe(data$RINCOME, na.rm = TRUE)
qqnorm(data$RINCOME)

#Question1c
quantile(data$RINCOME,na.rm = TRUE)

#you can observe that the quantile function first arranges the input values in the ascending order, 
#and then returns the required percentiles of the values.The quantile function divides the data into equal halves, 
#in which the median acts as middle and over that the remaining lower part is lower quartile and upper part is upper quartile

#Question2a
plot(data$RINCOME , data$EDUC , main = "RINCOME VS EDUC") 
cor.test(data$RINCOME, data$EDUC,method = "pearson")
#The p-value of the test is less than 2.2e-16, which is less than the significance level alpha = 0.05. 
#We can conclude that RINCOME and EDUC are significantly correlated with a correlation coefficient of 0.42 and p-value < 2.2e-16.

#Question2b
plot(data$EDUC , data$MAEDUC , main = "EDUC VS MAEDUC") 
cor.test(data$MAEDUC, data$EDUC,method = "pearson")
#The p-value of the test is less than 2.2e-16, which is less than the significance level alpha = 0.05. 
#We can conclude that MAEDUC and EDUC are significantly correlated with a correlation coefficient of 0.45 and p-value < 2.2e-16.

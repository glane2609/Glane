#Question1
N <- readline(prompt="Enter Number: ")
l<- readline(prompt = " Enter Length :")
x <- readline(prompt= "enter the divider1 :")
y <- readline(prompt= "enter the divider2 :")


l = 1
    if (as.numeric(N) %% as.numeric(x) == 0 & N %% as.numeric(y) == 0) {print("is the current number divisible by both")}
    
    else (as.numeric(N) %% as.numeric(x) == 0) {print("is the current number divisible by the first")}
    else  (as.numeric(N) %% as.numeric(y) == 0) {print("is the current number is divisible by the first")}
    else  ( as.numeric(N) %% as.numeric(x) != 0 & N %% as.numeric(y) != 0) {print ("is the current number divisible by none")}
    else print(as.numeric(N))
    l = l +1
}

#Question2
T <- readline(prompt="Enter text: ")
K <- readline(prompt="Enter key letter: ")
sapply(strsplit(T,""), function(K) sum(K=='l'))



#Question3
Nth.delete<-function(dataframe, n)dataframe[-(seq(n,to=nrow(dataframe),by=n)),]
DF<-data.frame(A=1:15)
Nth.delete(DF, 3)

#Question4
M <- matrix(c(1:8), ncol = 4)
print(M)
rotate <- function(M)"[<-"(M, , rev(M))
rotate(M)


#Question5
#Dataframe1
emp.data <- data.frame(
  emp_id = c (1:5), 
  emp_name = c("Rick","Dan","Michelle","Ryan","Gary"),stringsAsFactors = FALSE)
emp.data
#row
emp.data[2,]
#Dataframe2
emp.data1 <- data.frame(
  salary = c(623.3,515.2,611.0,729.0,843.25), 
  
  start_date = as.Date(c("2012-01-01", "2013-09-23", "2014-11-15", "2014-05-11",
                         "2015-03-27")),
  stringsAsFactors = FALSE)
emp.data1
emp.data1[3,]

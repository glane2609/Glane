library(ISLR)
data("Auto")

#Remove Nas 
na.omit(Auto)
View(Auto)
Auto$originf <- factor(Auto$origin, labels = c("usa", "europe", "japan"))
str(Auto)

#Quantitative: mpg, cylinders, displacement, horsepower, weight, acceleration, year. Qualitative: name, origin, originf

range(Auto$mpg)
range(Auto$cylinders)
range(Auto$cylinders)
range(Auto$displacement)
range(Auto$horsepower)
range(Auto$weight)
range(Auto$acceleration)
range(Auto$year)

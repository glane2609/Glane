library(readtext)
library(quanteda)
library(RColorBrewer)
library(tm)
library(wordcloud)
library(wordcloud2)


## Setting Directory 


setwd("~/Downloads")


DATA_60min <- "C:/Users/glane/Downloads/60 Minutes copy/"

min_files <- readtext(paste0(DATA_60min, "/*"),
                      docvarsfrom = "filenames",
                      dvsep="_",
                      docvarnames = c("Host", "Date"))
minutes<-VectorSource(min_files)
minutes_Corpus <- Corpus(minutes)
minutes_Corpus

#Data Cleaning
minutes_Corpus<-tm_map(minutes_Corpus, content_transformer(tolower) )
minutes_Corpus<-tm_map(minutes_Corpus, removePunctuation)
minutes_Corpus<-tm_map(minutes_Corpus, removeNumbers )
minutes_Corpus<-tm_map(minutes_Corpus, stripWhitespace)
minutes_Corpus<-tm_map(minutes_Corpus, removeWords , stopwords("russian"))

dtm<-DocumentTermMatrix(minutes_Corpus)
dtm2<-as.matrix(dtm)
View(dtm2[1:5 , 1:5])

# remove words in term matrix with length < 3
index <- as.logical(sapply(rownames(dtm2), function(x) (nchar(x)>3) ))
dtm2_s <- dtm2[index,]
head(dtm2_s)

frequency<-rowSums(dtm2)
frequency<-sort(frequency,decreasing = T)
frequency


df <- data.frame(word = names(frequency),freq=frequency)

set.seed(1234) # for reproducibility 
wordcloud(words = df$word, freq = df$freq, min.freq = 1,           
          max.words=200, random.order=FALSE, rot.per=0.35,           
          colors=brewer.pal(8, "Dark2"))
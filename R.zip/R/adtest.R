library(dplyr)
data<-read.csv("C:/Users/glane/Downloads/adtest.csv")
View(data)
#Paris
is.matrix(data$Paris)
x<- t(data$Paris)
x<-na.omit(data$Paris)
x<-NROW(x)
View(x)

#Serbia1
is.matrix(data$Serbia1)
y<- t(data$Serbia1)
y<-na.omit(data$Serbia1)
y<-NROW(y)
View(y)

#For m = 350 , n = 200
#PARIS
x1 <- 1/x
View(x1)
x2<- 1- x1
View(x2)
#Subszie 200
x3 <- (x2-x1)/200
x3

#For m = 350 , n = 350
#SERBIA1
y1<- 1/y
View(y1)
y2<- 1 - y1
View(y2)
#Subsize 350
y3<- (y2-y1)/350
y3

#Percentile
n = 1:200
n1 = as.vector(n)
for(n in n1){
  g<-quantile(data$Paris, probs = 0.1)
}
print(g)
#Here i is your L column values from sheet
k = 550
i = 10
c = 1
m = 350 
n = 200
ad <- (((k*c) -(m*i))^2)/ (i *(k-i))
ad

#i1 = as.vector(i)
#c1 = as.vector(c)

#for(i in i1){
     for(c in c1){
     ad <- (((k*c1) -(m*i1))^2)/ (i1 *(k-i1))
  }
  }
  
#print(ad)
#AD_stat <-sum(ad)/(m*n)
#AD_stat

library(data.table)
library(dplyr)
library(caTools)
library(caret)
default<-as.data.frame(fread("C:/Users/glane/Downloads/credit_card_default.tsv"))
View(default)

#change outcome to factor
default$default_next_month = factor(default$default_next_month)

default$sex = factor(default$sex)
default$education = factor(default$education)
default$marriage = factor(default$marriage)
default$pay_sept = factor(default$pay_sep)
default$pay_aug = factor(default$pay_aug)
default$pay_july = factor(default$pay_july)
default$pay_june = factor(default$pay_june)
default$pay_may = factor(default$pay_may)
default$pay_april = factor(default$pay_april)


#divide data into test and trian
sample.split(default$default_next_month,SplitRatio = 0.65)-> split_tag
subset(default, split_tag==T)->train
subset(default, split_tag==F)->test

#Save training set into new DF
training_set = select(train, -default_next_month)

#grow one tree
#tree_model in console
tree_model = train(y = train$default_next_month,
                   x = training_set, method = "rpart")

#tree model final model
tree_model$finalModel

#plot
library(rpart.plot)

rpart.plot(tree_model$finalModel)

#visual - suggesting payment status in two months prior are critical to defaulter?

plot(varImp(tree_model))

#visual

#tree predictions
tree_predictions = predict(tree_model, newdata = test)

#validation
confusionMatrix(tree_predictions, test$default_next_month)

#view confusion matrix

#techniques
#bagging*****************
bagged_model = train(y = train$default_next_month,
                     x = training_set, method = "treebag")

plot(varImp(bagged_model))

bagged_predictions = predict(bagged_model, test)
confusionMatrix(bagged_predictions, test$default_next_month)



-----------------------------------------
  #confusion matrix
  
 
sample.split(default$default_next_month,SplitRatio = 0.65)-> split_tag
subset(default, split_tag==T)->train
subset(default, split_tag==F)->test

nrow(train)
nrow(test)

glm(default_next_month~sex+education+marriage+pay_sept+pay_aug+pay_july+pay_june+pay_may+pay_april, data=train, family = "binomial")-> mod_log
predict(mod_log,newdata=test,type="response")->result_log
head(result_log)

range(result_log)

table(test$default_next_month, result_log>0.3)

library(ROCR)

prediction(result_log,test$default_next_month) -> predict_log
performance(predict_log,"acc")->acc
plot(acc)

table(test$default_next_month, result_log>0.41)
performance(predict_log,"tpr","fpr") -> roc_curve
plot(roc_curve)
plot(roc_curve, colorize=T)

results = resamples(list(tree = tree_model, bagged = bagged_model,
                         logistic = mod_log))

summary(results)

#plot results
dotplot(results)

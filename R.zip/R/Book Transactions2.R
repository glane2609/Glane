library(data.table)
library(dplyr)
data<-fread("C:/Users/glane/Downloads/book_transaction.csv"  )
View(data)

# take a look at the column properties
str(data)

# specify the date format for DATE variable
data[, DATE:=as.Date(DATE,format="%m/%d/%Y")]  

str(data)
head(data)

# summary data
table(is.na(data))
summary(data)

data[, hist(BOOKS, breaks = 100)]
data[, hist(DOLLARS, breaks = 100)]
data[, hist(DOLLARS/BOOKS, breaks = 100)]


#split the data into calibration and validation samples at 9/30/17
data.calibration<-data[DATE<=as.Date(c("2017-09-30")),]
data.validation<-data[DATE>as.Date(c("2017-09-30")),]

# create new data frames that aggregate info at per ID level
# monetary = average spend
# frequency = number of separate orders
# lastpurchase = date of most recent purchase
# numBOOKS = average number of BOOKS ordered
new.calibration <- data.calibration[,list(monetary=mean(DOLLARS),
                                          frequency=length(DOLLARS),
                                          lastpurchase=as.Date(max(DATE)),
                                          recency=as.numeric(max(data.calibration$DATE)-max(DATE)),
                                          numbooks=sum(BOOKS)),
                                    by=.(ID)]

new.validation <- data.validation[,list(monetary=mean(DOLLARS),
                                        frequency=length(DOLLARS),
                                        lastpurchase=as.Date(max(DATE)),
                                        recency=as.numeric(max(data.validation$DATE)-max(DATE)),
                                        numbooks=sum(BOOKS)),
                                  by=.(ID)]


#Merge calibration and validation samples into wide format where NAs in the validation indicate not being retained
new<-merge(new.calibration, new.validation, by = c("ID"), all.x = TRUE)

#creates another column which returns a 1 if customer purchases in the validation period, 0 otherwise
new[,retained:=as.numeric(!is.na(monetary.y))]




#Linear regression
linearfit <-lm(retained ~ recency.x + frequency.x + monetary.x, data=new)
summary(new.linearfit)
new[, linearfit:=predict(new.linearfit, type="response")]

hist(new$linearfit)

data[, FlorenceProb := predict(mod2,type="response")]
head(data)
summary(data$FlorenceProb)

data[, plot(sort(FlorenceProb,decreasing = T))]

data[, FlorencePred:= ifelse(FlorenceProb>=0.5, 1, 0)]
head(data)
data[, table(Florence, FlorencePred)]



#Monetary
monetaryprediction = expand.grid(recency.x=mean(new$recency.x),
                                 frequency.x=mean(new$frequency.x),
                                 monetary.x=seq(min(new$monetary.x),max(new$monetary.x)))
monetaryprediction$linearfit <- predict(new.linearfit, monetaryprediction,type="response")
plot(monetaryprediction$monetary.x,monetaryprediction$linearfit,col=3)

#Frequency
Frequencyprediction = expand.grid(recency.x=mean(new$recency.x),
                                 frequency.x=mean(new$frequency.x),
                                 monetary.x=seq(min(new$monetary.x),max(new$monetary.x)))
Frequencyprediction$linearfit <- predict(new.linearfit, Frequencyprediction,type="response")
plot(Frequencyprediction$frequency.x,Frequencyprediction$linearfit,col=3)

#Recency
Recencyprediction = expand.grid(recency.x=mean(new$recency.x),
                                  frequency.x=mean(new$frequency.x),
                                  monetary.x=seq(min(new$monetary.x),max(new$monetary.x)))
Recencyprediction$linearfit <- predict(new.linearfit, Recencyprediction,type="response")
plot(Recencyprediction$recency.x,Recencyprediction$linearfit,col=3)



#Logistic regression
new.logitfit <-glm(retained ~ recency.x + frequency.x + monetary.x, data=new,family="binomial")
summary(new.logitfit)

new$score=predict(new.logitfit, newdata=new, type='response')
plot(new.logitfit)

#Monetary prediction for Logistic regression
monetaryprediction1 = expand.grid(recency.x=mean(new$recency.x),
                                 frequency.x=mean(new$frequency.x),
                                 monetary.x=seq(min(new$monetary.x),max(new$monetary.x)))
monetaryprediction1$logitfit <- predict(new.logitfit, monetaryprediction1,type="response")
plot(monetaryprediction1$monetary.x,monetaryprediction1$logitfit,col=3)
View(monetaryprediction1)

#Frequency prediction for Logistic regression
Frequencyprediction1 = expand.grid(recency.x=mean(new$recency.x),
                                  frequency.x=mean(new$frequency.x),
                                  monetary.x=seq(min(new$monetary.x),max(new$monetary.x)))
Frequencyprediction1$logitfit <- predict(new.logitfit, Frequencyprediction1,type="response")
plot(Frequencyprediction1$frequency.x,Frequencyprediction1$logitfit,col=3)


#Recency prediction for Logistic regression
Recencyprediction1 = expand.grid(recency.x=mean(new$recency.x),
                                   frequency.x=mean(new$frequency.x),
                                   monetary.x=seq(min(new$monetary.x),max(new$monetary.x)))
Recencyprediction1$logitfit <- predict(new.logitfit, Recencyprediction1,type="response")
plot(Recencyprediction1$logi,Recencyprediction1$lrecency.x,col=3)



#Decile analysis

new = mutate(new, quantile_rank_monetary = ntile(desc(new$monetary.x),4),quantile_rank_frequency = ntile(desc(new$frequency.x),4),quantile_rank_recency = ntile(desc(new$recency.x),4))

#Percent retention
library(dplyr)
pct_monetary <- new %>% group_by(quantile_rank_monetary) %>% summarise(Pct = quantile_rank_monetary/sum(new$quantile_rank_monetary) * 100)
pct_monetary
plot(pct_monetary)

pct_recency <- new %>% group_by(quantile_rank_recency) %>% summarise(Pct = quantile_rank_recency/sum(new$quantile_rank_recency) * 100)
pct_recency
plot(pct_recency)

pct_frequency <- new %>% group_by(quantile_rank_frequency) %>% summarise(pct = quantile_rank_frequency/sum(new$quantile_rank_frequency) * 100)
pct_frequency
plot(pct_frequency)


#Q.4.A,B,C,D
#Cumulative lift chart
library(funModeling)
gain_lift(data=new, score='score', target='retained')
gain_lift(data=monetaryprediction1,score = 'logitfit',target = 'recency.x')

# For Data = new ,the Cumulative Lift decreases as population % increases from 10 to 20 and so on
#Q.4.C
# For data = monetaryprediction , the Cumulative Lift is stable for all the population

#Q.4.D
#The gain plot increases linearly for RFM model with data = monetaryprediction


Q.4.E
#Gain
library(funModeling)

gain_lift(data=new,score = 'score',target = 'frequency.x')
gain_lift(data=monetaryprediction1,score = 'logitfit',target = 'frequency.x')

#Q.4.F

#The gain plot for variable frequency.x shows 0 gain till 70% population and then increases with 100% stability whereas lift starts decreasing from 80% to 100%


load("C:/Users/glane/Downloads/mayangna_nn_ipa.rda")
View(output)
class(output)
library("purrr")
data= as.data.frame(output, stringsAsFactors = FALSE)
data = map_df(data, as.numeric)
str(data, list.len=ncol(data))

summary(data)



# Random sampling
samplesize = 0.60 * nrow(data)
set.seed(80)
index = sample( seq_len ( nrow ( data ) ), size = samplesize )


## Scale data for neural network

max = apply(data , 2 , max)
min = apply(data, 2 , min)
scaled = as.matrix(scale(data, center = min, scale = max - min))
scaled[is.nan(scaled)]<-1
scaled = as.data.frame(scaled,stringsAsFactors = FALSE)
str(scaled)
## Fit neural network 

# install library
install.packages("neuralnet")

# load library
library(neuralnet)

# creating training and test set
trainNN = scaled[index , ]

trainNN
trainNN[is.nan(unlist(trainNN))]<-1
testNN = scaled[-index , ]

testNN

# fit neural network

NN = neuralnet(V161~., trainNN, hidden = 1 , linear.output = T )

# plot neural network
plot(NN)

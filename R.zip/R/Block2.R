# Create the data frame.
test <- data.frame(x = c(26, 21, 20), y = c(34, 29, 28))
test
#Vector
as.vector(t(test))
#Min-Max
min(test)
max(test)
#Indexing
colnames(test)
rownames(test)
#Number of rows and columns 
nrow(test)
ncol(test)

#Question2
emp.data <- data.frame(
   emp_name = c("Rick","Dan","Dogsareloyal" , "HelloWorld"), stringsAsFactors = FALSE)
Un1 <- unique(emp.data$emp_name)
data.frame(Group=Un1, x=nchar(Un1))
f <- function(emp.data, n) sort(table(emp.data), decreasing = TRUE)[1:n]
lapply(emp.data, f, n = 3)
#Question3
# Create the data frame.
emp.data1 <- data.frame(
  emp_id1 = c (1:5), 
  emp_name1 = c("Rick","Dan","Michelle","Ryan","Gary"),
  salary1 = c(623.3,515.2,611.0,729.0,843.25), 
  
  start_date1 = as.Date(c("2012-01-01", "2013-09-23", "2014-11-15", "2014-05-11",
                         "2015-03-27")),
  stringsAsFactors = FALSE
)
# Print the data frame.			
print(emp.data1) 

na.omit(emp.data1)

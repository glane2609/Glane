library(dplyr)
library(readxl)
library(lubridate)
library(prophet)
library(ggplot2)
covid<- read_xlsx("C:/Users/glane/Downloads/DATASET_FINAL.xlsx")
View(covid)
str(covid)
covid$date <- ymd(covid$date)

#India ( new cases )
covid_india <- filter(covid , location == "India")

#Plot
qplot(date,new_cases,data = covid_india)
ds_India_new <- covid_india$date
y_India_new <- covid_india$new_cases

df_India_new<- data.frame(ds=ds_India_new,y= y_India_new)

#Forecasting
f <- prophet(df_India_new)

#Prediction for next 100 days of new cases
future <- make_future_dataframe(f , periods = 100)
forecast <- predict(f, future) #Store prediction

#Plot
dyplot.prophet(f,forecast)


#India ( death cases )

#Plot
qplot(date,new_deaths,data = covid_india)
ds_India_death <- covid_india$date
y_India_death <- covid_india$new_deaths

df_India_death<- data.frame(ds=ds_India_death,y= y_India_death)

#Forecasting
f_death <- prophet(df_India_death)

#Prediction for next 100 days of death cases
future_death <- make_future_dataframe(f_death , periods = 100)
forecast_death <- predict(f_death, future) #Store prediction

#Plot
dyplot.prophet(f_death,forecast_death)

#Splitting New cases in 70:30 ratio
library(caTools)
covid_india[is.na(covid_india)] <- 0
sample.split(covid_india$new_cases,SplitRatio = 0.70)-> split_tag
subset(covid_india, split_tag==T)->train
subset(covid_india, split_tag==F)->test


library(randomForest)


randomForest(new_cases ~ new_deaths+reproduction_rate+new_tests+positive_rate+tests_per_case+stringency_index+population_density+median_age+aged_65_older+aged_70_older, data = train,mtry=4, ntree=100) -> model 

importance(model)
varImpPlot(model)
varImpPlot(model, col="palegreen4")

predict(model,newdata=test,type="class")->result_forest
View(result_forest)
table(test$new_cases, result_forest)

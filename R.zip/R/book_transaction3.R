
rm(list=ls())
library(data.table)
#install.packages("dplyr")
library(dplyr)
#install.packages("pROC")
library("pROC")

data = fread("C:/Users/glane/Downloads/book_transaction.csv")

# understand the data
head(data)
str(data)

summary(data)

data[, DATE:=as.Date(DATE,format="%m/%d/%Y")] 

#split the data into calibration and validation samples at 9/30/17
data.calibration<-data[DATE<=as.Date(c("2017-09-30")),]
data.validation<-data[DATE>as.Date(c("2017-09-30")),]

# create new data frames that aggregate info at per ID level
# monetary = average spend
# frequency = number of separate orders
# lastpurchase = date of most recent purchase
# numBOOKS = average number of BOOKS ordered

new.calibration <- data.calibration[,list(monetary=mean(DOLLARS),
                                          frequency=length(DOLLARS),
                                          lastpurchase=as.Date(max(DATE)),
                                          recency=as.numeric(max(data.calibration$DATE)-max(DATE)),
                                          numbooks=sum(BOOKS)),
                                    by=.(ID)]

new.validation <- data.validation[,list(monetary=mean(DOLLARS),
                                        frequency=length(DOLLARS),
                                        lastpurchase=as.Date(max(DATE)),
                                        recency=as.numeric(max(data.validation$DATE)-max(DATE)),
                                        numbooks=sum(BOOKS)),
                                  by=.(ID)]

#Merge calibration and validation samples into wide format where NAs in the validation indicate not being retained
new<-merge(new.calibration, new.validation, by = c("ID"), all.x = TRUE)

#creates another column which returns a 1 if customer purchases in the validation period, 0 otherwise
new[,retained:=as.numeric(!is.na(monetary.y))]

#Linear regression
linearfit <-lm(retained ~ recency.x + frequency.x + monetary.x, data=new)
summary(linearfit)
new[, linearprob := predict(linearfit, type="response")]
summary(new$linearprob)
new[, plot(sort(linearprob,decreasing = T))]

new[, linearPred:= ifelse(linearprob>=0.5, 1, 0)]
head(new)
new[, table(retained, linearPred)]

# ROC curve
# y-axis is the sensitivity: the probability that the model predicts a response when customers actually respond (positive responses)
# x-axis is (100%-specificity)
# specificity refers to the % of predicted non-responses contained in the group of customers not selected by the model
# thus, a good model is the one with high sensitivity and low false positive rate (100%-specifity)

data.roc = new[, roc(retained, linearprob, percent=T)]
auc(data.roc)
plot(data.roc,smooth=T)
coords(data.roc,"best","specificity",transpose = F)

new[, linearPred := ifelse(linearprob>=0.1048957, 1, 0)]
head(new)
new[, table(retained, linearPred)]


# using Logistic Regression 
logitfit = glm(retained ~ recency.x + frequency.x + monetary.x, data=new, family=binomial(link="logit"))
summary(logitfit)
            

new[, logitProb := predict(logitfit,type="response")]
head(new)
summary(new$logitProb)

new[, plot(sort(logitProb,decreasing = T))]

new[, logitPred:= ifelse(logitProb>=0.5, 1, 0)]
head(new)
new[, table(retained, logitPred)]

data.roc1 = new[, roc(retained, logitProb, percent=T)]
auc(data.roc1)
plot(data.roc1,smooth=T)
coords(data.roc1,"best","specificity",transpose = F)

new[, logitPred := ifelse(logitProb>=0.1048957, 1, 0)]
head(new)
new[, table(retained, logitPred)]


#Monetary prediction for Logistic regression
monetaryprediction1 = expand.grid(recency.x=mean(new$recency.x),
                                  frequency.x=mean(new$frequency.x),
                                  monetary.x=seq(min(new$monetary.x),max(new$monetary.x)))
monetaryprediction1$fit <- predict(logitfit, monetaryprediction1,type="response")
plot(monetaryprediction1$monetary.x,monetaryprediction1$fit,col=3)
View(monetaryprediction1)

#Frequency prediction for Logistic regression
Frequencyprediction1 = expand.grid(recency.x=mean(new$recency.x),
                                   frequency.x=mean(new$frequency.x),
                                   monetary.x=seq(min(new$monetary.x),max(new$monetary.x)))
Frequencyprediction1$fit <- predict(logitfit, Frequencyprediction1,type="response")
plot(Frequencyprediction1$frequency.x,Frequencyprediction1$fit,col=3)


#Recency prediction for Logistic regression
Recencyprediction1 = expand.grid(recency.x=mean(new$recency.x),
                                 frequency.x=mean(new$frequency.x),
                                 monetary.x=seq(min(new$monetary.x),max(new$monetary.x)))
Recencyprediction1$logitfit <- predict(new.logitfit, Recencyprediction1,type="response")
plot(Recencyprediction1$logi,Recencyprediction1$lrecency.x,col=3)



#Decile analysis

new = mutate(new, quantile_rank_monetary = ntile(desc(new$monetary.x),4),quantile_rank_frequency = ntile(desc(new$frequency.x),4),quantile_rank_recency = ntile(desc(new$recency.x),4))

#Percent retention
library(dplyr)
pct_monetary <- new %>% group_by(quantile_rank_monetary) %>% summarise(Pct = quantile_rank_monetary/sum(new$quantile_rank_monetary) * 100)
pct_monetary
plot(pct_monetary)

pct_recency <- new %>% group_by(quantile_rank_recency) %>% summarise(Pct = quantile_rank_recency/sum(new$quantile_rank_recency) * 100)
pct_recency
plot(pct_recency)

pct_frequency <- new %>% group_by(quantile_rank_frequency) %>% summarise(pct = quantile_rank_frequency/sum(new$quantile_rank_frequency) * 100)
pct_frequency
plot(pct_frequency)



# random selection vs. targeting
new[, logitProb_quantile:=ntile(logitProb,10)]

new[,table(logitProb_quantile)]
targeted = new[, list(n.retained=sum(retained),
                       n=length(retained),
                       rate_observed=sum(retained)/length(retained),
                       rate_predicted=mean(logitProb)),
                by=.(logitProb_quantile)]
targeted
targeted = targeted[order(-logitProb_quantile),]
targeted
targeted[,plot(order(-logitProb_quantile),rate_predicted,type="b")]
targeted[,abline(h=max(rate_predicted),col=2)]



# cumulative lift chart Q.4.B
setorder(targeted,-logitProb_quantile)
targeted
targeted[,cumlift:=(cumsum(n.retained)/cumsum(n))/(sum(n.retained)/sum(n))] 
targeted[,cumcustomerpt:=cumsum(n)/sum(n)]
targeted
targeted[, plot(cumcustomerpt,cumlift,type="b")]

# Gain chart #Q.4.D
setorder(targeted,-logitProb_quantile)

targeted[,gains:=(cumsum(n.retained)/sum(n.retained))] 
targeted[,cumcustomerpt:=cumsum(n)/sum(n)]
targeted
targeted[, plot(cumcustomerpt,gains,type="b",ylim=c(0,1),xlim=c(0,1),main="gain chart")]; abline(h=100, col="blue")



#Q.4.A,B,C,D
#Cumulative lift chart
library(funModeling)

gain_lift(data=new, score='logitProb_quantile', target='retained')

gain_lift(data=monetaryprediction1,score = 'fit',target = 'recency.x')

# For Data = new ,the Cumulative Lift decreases as population % increases from 10 to 20 and so on
#Q.4.C
# For data = monetaryprediction , the Cumulative Lift is stable for all the population

#Q.4.D
#The gain plot increases linearly for RFM model with data = monetaryprediction

Q.4.E
#Gain
library(funModeling)

gain_lift(data=new,score = 'logitProb_quantile',target = 'frequency.x')
gain_lift(data=Frequencyprediction1,score = 'fit',target = 'frequency.x')

#Q.4.F

#The gain plot for variable frequency.x shows 0 gain till 70% population and then increases with 100% stability whereas lift starts decreasing from 80% to 100%